# Turn the runtime source into a C string so generated programs can carry it.
import sys
src, dst = sys.argv[1], sys.argv[2]
out = ['/* generated from rt.c by tools/embed.py - do not edit */', 'static const char RT_SRC[] =']
for line in open(src, encoding='utf-8').read().split('\n'):
    esc = ''
    for ch in (line + '\n').encode('utf-8'):
        c = chr(ch)
        if c == '\\': esc += '\\\\'
        elif c == '"': esc += '\\"'
        elif c == '\n': esc += '\\n'
        elif c == '?': esc += '\\?'
        elif 32 <= ch < 127: esc += c
        else: esc += '\\%03o' % ch
    out.append('  "' + esc + '"')
out[-1] += ';'
open(dst, 'w', encoding='utf-8').write('\n'.join(out) + '\n')
