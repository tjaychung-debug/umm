import base64, sys
t = open('web/index.template.html', encoding='utf-8').read()
b = base64.b64encode(open('build/dot.wasm', 'rb').read()).decode()
open('index.html', 'w', encoding='utf-8').write(t.replace('__WASM_BASE64__', b))
