/* ===================================================================
 * umm runtime
 * Values, containers, built-in algorithms, I/O.
 * Shared by the interpreter (compiled to WebAssembly) and by every
 * generated submission file (compiled natively with RT_NATIVE).
 * =================================================================== */
#ifdef RT_NATIVE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define RT_SQRT(x) sqrt(x)
#define RT_FLOOR(x) floor(x)
#define RT_NORETURN __attribute__((noreturn))
#else
#include <stddef.h>
#define RT_SQRT(x) __builtin_sqrt(x)
#define RT_FLOOR(x) __builtin_floor(x)
#define RT_NORETURN __attribute__((noreturn))
void *memcpy(void *d, const void *s, size_t n) { unsigned char *a = d; const unsigned char *b = s; while (n--) *a++ = *b++; return d; }
void *memmove(void *d, const void *s, size_t n) {
  unsigned char *a = d; const unsigned char *b = s;
  if (a < b) { while (n--) *a++ = *b++; } else { a += n; b += n; while (n--) *--a = *--b; }
  return d;
}
void *memset(void *d, int c, size_t n) { unsigned char *a = d; while (n--) *a++ = (unsigned char)c; return d; }
int memcmp(const void *x, const void *y, size_t n) {
  const unsigned char *a = x, *b = y;
  for (; n; n--, a++, b++) if (*a != *b) return *a < *b ? -1 : 1;
  return 0;
}
size_t strlen(const char *s) { size_t n = 0; while (s[n]) n++; return n; }
__attribute__((import_module("env"), import_name("js_error"))) void js_error(const char *p, int len);
#endif

typedef long long i64;

enum { T_INT = 0, T_DBL, T_STR, T_LIST, T_MAP, T_SET, T_PQ, T_DEQ, T_FN, T_NIL };

typedef struct V { int t; union { i64 i; double d; void *p; } u; } V;
typedef struct { int n, cap; char *s; } Str;
typedef struct { int n, cap; V *a; } List;
typedef struct TN { V k, v; unsigned pr; struct TN *l, *r; } TN;
typedef struct { TN *root; int n; } Tree;
typedef struct { List *h; int mode; V cmp; } Pq;
typedef struct { V *a; int head, n, cap; } Deq;
typedef struct { int bi; void *fp; void *ast; int arity; } Fn;

static int rt_line = 0;
static V (*rt_hook_apply)(void *ast, V *args, int n) = 0;

/* ------------------------------------------------------------------ */
/* errors                                                              */
/* ------------------------------------------------------------------ */
static void rt_flush(void);
static int rt_fmt_int(char *buf, i64 x);

static RT_NORETURN void rt_error(const char *msg) {
  char buf[512]; int n = 0;
  const char *pre = "실행 오류";
  while (*pre && n < 400) buf[n++] = *pre++;
  if (rt_line > 0) {
    const char *l = " (줄 "; while (*l) buf[n++] = *l++;
    n += rt_fmt_int(buf + n, rt_line);
    buf[n++] = ')';
  }
  buf[n++] = ':'; buf[n++] = ' ';
  while (*msg && n < 500) buf[n++] = *msg++;
  buf[n] = 0;
#ifdef RT_NATIVE
  rt_flush();
  fprintf(stderr, "%s\n", buf);
  exit(1);
#else
  js_error(buf, n);
  __builtin_trap();
#endif
}

/* ------------------------------------------------------------------ */
/* memory                                                              */
/* ------------------------------------------------------------------ */
#ifdef RT_NATIVE
static void *rt_alloc(size_t n) { void *p = calloc(1, n ? n : 1); if (!p) rt_error("메모리가 부족해요"); return p; }
static void *rt_grow(void *p, size_t old, size_t n) {
  void *q = realloc(p, n ? n : 1); if (!q) rt_error("메모리가 부족해요");
  if (n > old) memset((char *)q + old, 0, n - old);
  return q;
}
#else
extern unsigned char __heap_base;
static size_t heap_ptr = 0, heap_end = 0;
static void *rt_alloc(size_t n) {
  n = (n + 7) & ~(size_t)7;
  if (!heap_ptr) { heap_ptr = ((size_t)&__heap_base + 7) & ~(size_t)7; heap_end = __builtin_wasm_memory_size(0) * 65536; }
  if (heap_ptr + n > heap_end) {
    size_t pages = (heap_ptr + n - heap_end + 65535) / 65536;
    if (__builtin_wasm_memory_grow(0, pages) == (size_t)-1) rt_error("메모리가 부족해요");
    heap_end += pages * 65536;
  }
  void *p = (void *)heap_ptr; heap_ptr += n;
  memset(p, 0, n);
  return p;
}
static void *rt_grow(void *p, size_t old, size_t n) {
  if (n <= old) return p;
  size_t o8 = (old + 7) & ~(size_t)7;
  if (p && (size_t)p + o8 == heap_ptr) { rt_alloc(n - o8); return p; }  /* extend last block in place */
  void *q = rt_alloc(n);
  if (p && old) memcpy(q, p, old);
  return q;
}
#endif

/* ------------------------------------------------------------------ */
/* constructors and helpers                                            */
/* ------------------------------------------------------------------ */
static V vi(i64 x) { V v; v.t = T_INT; v.u.i = x; return v; }
static V vd(double x) { V v; v.t = T_DBL; v.u.d = x; return v; }
static V vnil(void) { V v; v.t = T_NIL; v.u.i = 0; return v; }
static V vobj(int t, void *p) { V v; v.t = t; v.u.p = p; return v; }
static int isnum(V a) { return a.t == T_INT || a.t == T_DBL; }
static double todbl(V a) { return a.t == T_INT ? (double)a.u.i : a.u.d; }

static const char *rt_tname(int t) {
  switch (t) {
    case T_INT: return "정수"; case T_DBL: return "실수"; case T_STR: return "문자열";
    case T_LIST: return "리스트"; case T_MAP: return "맵"; case T_SET: return "집합";
    case T_PQ: return "우선순위 큐"; case T_DEQ: return "큐"; case T_FN: return "함수";
    default: return "nil";
  }
}
static RT_NORETURN void rt_type_error(const char *what, V a) {
  char buf[200]; int n = 0;
  const char *s = what; while (*s) buf[n++] = *s++;
  s = " (받은 값: "; while (*s) buf[n++] = *s++;
  s = rt_tname(a.t); while (*s) buf[n++] = *s++;
  buf[n++] = ')'; buf[n] = 0;
  rt_error(buf);
}
static i64 toint(V a, const char *what) {
  if (a.t == T_INT) return a.u.i;
  if (a.t == T_DBL) return (i64)a.u.d;
  rt_type_error(what, a);
}

static Str *mkstr(const char *s, int n) {
  Str *x = rt_alloc(sizeof(Str));
  x->n = n; x->cap = n + 1; x->s = rt_alloc(n + 1);
  if (n) memcpy(x->s, s, n);
  return x;
}
static V vstr(const char *s, int n) { return vobj(T_STR, mkstr(s, n)); }
static V rt_strlit(const char *s) { return vstr(s, (int)strlen(s)); }
static List *mklist(int cap) {
  List *l = rt_alloc(sizeof(List));
  l->cap = cap < 4 ? 4 : cap; l->a = rt_alloc(sizeof(V) * l->cap);
  return l;
}
static V vlist(int cap) { return vobj(T_LIST, mklist(cap)); }
static void lpush(List *l, V x) {
  if (l->n == l->cap) { int nc = l->cap * 2; l->a = rt_grow(l->a, sizeof(V) * l->cap, sizeof(V) * nc); l->cap = nc; }
  l->a[l->n++] = x;
}
#define LST(v) ((List *)(v).u.p)
#define STR(v) ((Str *)(v).u.p)

/* ------------------------------------------------------------------ */
/* number formatting / parsing                                         */
/* ------------------------------------------------------------------ */
static int rt_fmt_int(char *buf, i64 x) {
  char t[24]; int n = 0, k = 0;
  unsigned long long u = x < 0 ? (unsigned long long)(-(x + 1)) + 1 : (unsigned long long)x;
  if (x < 0) buf[k++] = '-';
  do { t[n++] = (char)('0' + u % 10); u /= 10; } while (u);
  while (n) buf[k++] = t[--n];
  return k;
}
/* fixed-point with prec digits; prec < 0 => up to 10 digits, trailing zeros trimmed */
static int rt_fmt_dbl(char *buf, double x, int prec) {
  int k = 0, trim = prec < 0;
  if (x != x) { memcpy(buf, "nan", 3); return 3; }
  if (x > 1e300 * 1e10) { memcpy(buf, "inf", 3); return 3; }
  if (x < -1e300 * 1e10) { memcpy(buf, "-inf", 4); return 4; }
  if (prec < 0) prec = 10;
  if (prec > 15) prec = 15;
  if (x < 0) { buf[k++] = '-'; x = -x; }
  double scale = 1; for (int i = 0; i < prec; i++) scale *= 10;
  if (x * scale < 9.0e18) {
    unsigned long long whole = (unsigned long long)(x * scale + 0.5);
    unsigned long long ip = whole, fp = 0, sc = 1;
    for (int i = 0; i < prec; i++) sc *= 10;
    ip = whole / sc; fp = whole % sc;
    k += rt_fmt_int(buf + k, (i64)ip);
    if (prec > 0) {
      char f[20]; for (int i = prec - 1; i >= 0; i--) { f[i] = (char)('0' + fp % 10); fp /= 10; }
      int len = prec;
      if (trim) while (len > 0 && f[len - 1] == '0') len--;
      if (len > 0) { buf[k++] = '.'; memcpy(buf + k, f, len); k += len; }
    }
    if (k == 2 && buf[0] == '-' && buf[1] == '0') { buf[0] = '0'; k = 1; }
    return k;
  }
  /* large magnitude: scientific notation */
  int e = 0; while (x >= 10) { x /= 10; e++; }
  unsigned long long m = (unsigned long long)(x * 1e9 + 0.5);
  if (m >= 10000000000ULL) { m /= 10; e++; }
  char d[12]; for (int i = 9; i >= 0; i--) { d[i] = (char)('0' + m % 10); m /= 10; }
  buf[k++] = d[0]; buf[k++] = '.';
  int len = 10; while (len > 2 && d[len - 1] == '0') len--;
  memcpy(buf + k, d + 1, len - 1); k += len - 1;
  buf[k++] = 'e'; k += rt_fmt_int(buf + k, e);
  return k;
}
/* returns 1 int, 2 double, 0 not a number */
static int rt_parse_num(const char *s, int n, i64 *iv, double *dv) {
  int i = 0, neg = 0, digits = 0, isd = 0;
  if (i < n && (s[i] == '-' || s[i] == '+')) { neg = s[i] == '-'; i++; }
  unsigned long long u = 0; double d = 0;
  while (i < n && s[i] >= '0' && s[i] <= '9') { u = u * 10 + (unsigned)(s[i] - '0'); d = d * 10 + (s[i] - '0'); i++; digits++; }
  if (i < n && s[i] == '.') {
    isd = 1; i++; double f = 0.1;
    while (i < n && s[i] >= '0' && s[i] <= '9') { d += (s[i] - '0') * f; f *= 0.1; i++; digits++; }
  }
  if (!digits) return 0;
  if (i < n && (s[i] == 'e' || s[i] == 'E')) {
    isd = 1; i++; int en = 0, es = 0;
    if (i < n && (s[i] == '-' || s[i] == '+')) { en = s[i] == '-'; i++; }
    while (i < n && s[i] >= '0' && s[i] <= '9') { es = es * 10 + (s[i] - '0'); i++; }
    while (es--) d = en ? d / 10 : d * 10;
  }
  if (i != n) return 0;
  if (!isd && digits <= 18) { *iv = neg ? -(i64)u : (i64)u; return 1; }
  *dv = neg ? -d : d; return 2;
}

/* ------------------------------------------------------------------ */
/* output / input                                                      */
/* ------------------------------------------------------------------ */
static char *out_buf = 0; static size_t out_len = 0, out_cap = 0;
static const char *in_buf = 0; static size_t in_len = 0, in_pos = 0;

static void rt_write(const char *s, size_t n) {
  if (out_len + n > out_cap) {
    size_t nc = out_cap ? out_cap * 2 : 1 << 16;
    while (nc < out_len + n) nc *= 2;
#ifndef RT_NATIVE
    if (nc > (size_t)32 << 20) rt_error("출력이 너무 많아요 (32MB 초과)");
#endif
    out_buf = rt_grow(out_buf, out_cap, nc); out_cap = nc;
  }
  memcpy(out_buf + out_len, s, n); out_len += n;
#ifdef RT_NATIVE
  if (out_len > (1 << 20)) rt_flush();
#endif
}
static void rt_putc(char c) { rt_write(&c, 1); }
static void rt_flush(void) {
#ifdef RT_NATIVE
  if (out_len) { fwrite(out_buf, 1, out_len, stdout); out_len = 0; }
  fflush(stdout);
#endif
}
static void rt_init(void) {
#ifdef RT_NATIVE
  size_t cap = 1 << 16, n = 0; char *b = malloc(cap);
  for (;;) {
    if (n == cap) { cap *= 2; b = realloc(b, cap); }
    size_t r = fread(b + n, 1, cap - n, stdin);
    if (!r) break; n += r;
  }
  in_buf = b; in_len = n; in_pos = 0;
#endif
}

static V rt_read(void) {
  while (in_pos < in_len && (unsigned char)in_buf[in_pos] <= ' ') in_pos++;
  if (in_pos >= in_len) rt_error("입력이 더 없어요");
  size_t st = in_pos;
  while (in_pos < in_len && (unsigned char)in_buf[in_pos] > ' ') in_pos++;
  i64 iv; double dv;
  int k = rt_parse_num(in_buf + st, (int)(in_pos - st), &iv, &dv);
  if (k == 1) return vi(iv);
  if (k == 2) return vd(dv);
  return vstr(in_buf + st, (int)(in_pos - st));
}
static V rt_readline(void) {
  if (in_pos < in_len && in_buf[in_pos] == '\n') in_pos++;
  size_t st = in_pos;
  while (in_pos < in_len && in_buf[in_pos] != '\n') in_pos++;
  size_t en = in_pos;
  if (en > st && in_buf[en - 1] == '\r') en--;
  return vstr(in_buf + st, (int)(en - st));
}

static void rt_print_inner(V v, int depth);
static void rt_print(V v) { rt_print_inner(v, 0); }

/* ------------------------------------------------------------------ */
/* treap (ordered set / map)                                           */
/* ------------------------------------------------------------------ */
static int rt_cmp(V a, V b);
static unsigned rng_state = 2463534242u;
static unsigned rng(void) { rng_state ^= rng_state << 13; rng_state ^= rng_state >> 17; rng_state ^= rng_state << 5; return rng_state; }

static void tr_split(TN *t, V k, TN **l, TN **r, int le) { /* le: left gets keys <= k ; else keys < k */
  if (!t) { *l = *r = 0; return; }
  int c = rt_cmp(t->k, k);
  if (c < 0 || (le && c == 0)) { tr_split(t->r, k, &t->r, r, le); *l = t; }
  else { tr_split(t->l, k, l, &t->l, le); *r = t; }
}
static TN *tr_merge(TN *a, TN *b) {
  if (!a) return b; if (!b) return a;
  if (a->pr > b->pr) { a->r = tr_merge(a->r, b); return a; }
  b->l = tr_merge(a, b->l); return b;
}
static TN *tr_find(TN *t, V k) {
  while (t) { int c = rt_cmp(k, t->k); if (!c) return t; t = c < 0 ? t->l : t->r; }
  return 0;
}
static TN *tr_insert(Tree *tr, V k, V v) {
  TN *f = tr_find(tr->root, k);
  if (f) return f;
  TN *n = rt_alloc(sizeof(TN)); n->k = k; n->v = v; n->pr = rng();
  TN *l, *r; tr_split(tr->root, k, &l, &r, 0);
  tr->root = tr_merge(tr_merge(l, n), r); tr->n++;
  return n;
}
static int tr_erase(Tree *tr, V k) {
  TN **p = &tr->root;
  while (*p) {
    int c = rt_cmp(k, (*p)->k);
    if (!c) { *p = tr_merge((*p)->l, (*p)->r); tr->n--; return 1; }
    p = c < 0 ? &(*p)->l : &(*p)->r;
  }
  return 0;
}
static TN *tr_lower(TN *t, V k, int strict) { /* first node with key >= k (or > k) */
  TN *best = 0;
  while (t) {
    int c = rt_cmp(t->k, k);
    if (c > 0 || (!strict && c == 0)) { best = t; t = t->l; } else t = t->r;
  }
  return best;
}
static void tr_collect(TN *t, List *out, int keys_only) {
  /* in-order; treap depth is O(log n) so recursion is safe */
  if (!t) return;
  tr_collect(t->l, out, keys_only);
  if (keys_only) lpush(out, t->k);
  else { V pair = vlist(2); lpush(LST(pair), t->k); lpush(LST(pair), t->v); lpush(out, pair); }
  tr_collect(t->r, out, keys_only);
}
static TN *tr_min(TN *t) { if (!t) return 0; while (t->l) t = t->l; return t; }
static TN *tr_max(TN *t) { if (!t) return 0; while (t->r) t = t->r; return t; }

/* ------------------------------------------------------------------ */
/* comparison, truthiness, conversion                                  */
/* ------------------------------------------------------------------ */
static int rt_cmp(V a, V b) {
  if (isnum(a) && isnum(b)) {
    if (a.t == T_INT && b.t == T_INT) return a.u.i < b.u.i ? -1 : a.u.i > b.u.i;
    double x = todbl(a), y = todbl(b); return x < y ? -1 : x > y;
  }
  if (a.t != b.t) return a.t < b.t ? -1 : 1;
  if (a.t == T_STR) {
    Str *x = STR(a), *y = STR(b); int n = x->n < y->n ? x->n : y->n;
    int c = memcmp(x->s, y->s, n); if (c) return c < 0 ? -1 : 1;
    return x->n < y->n ? -1 : x->n > y->n;
  }
  if (a.t == T_LIST) {
    List *x = LST(a), *y = LST(b); int n = x->n < y->n ? x->n : y->n;
    for (int i = 0; i < n; i++) { int c = rt_cmp(x->a[i], y->a[i]); if (c) return c; }
    return x->n < y->n ? -1 : x->n > y->n;
  }
  if (a.t == T_NIL) return 0;
  return a.u.p < b.u.p ? -1 : a.u.p > b.u.p;
}
static int rt_size(V a);
static int rt_truthy(V a) {
  switch (a.t) {
    case T_INT: return a.u.i != 0;
    case T_DBL: return a.u.d != 0;
    case T_NIL: return 0;
    case T_FN: return 1;
    default: return rt_size(a) > 0;
  }
}
static V rt_tostr(V a) {
  if (a.t == T_STR) return a;
  char buf[64]; int n;
  if (a.t == T_INT) n = rt_fmt_int(buf, a.u.i);
  else if (a.t == T_DBL) n = rt_fmt_dbl(buf, a.u.d, -1);
  else if (a.t == T_NIL) { memcpy(buf, "nil", 3); n = 3; }
  else {
    /* render through the printer */
    size_t save = out_len; rt_print(a);
    V s = vstr(out_buf + save, (int)(out_len - save)); out_len = save; return s;
  }
  return vstr(buf, n);
}

/* ------------------------------------------------------------------ */
/* printing                                                            */
/* ------------------------------------------------------------------ */
static void rt_print_inner(V v, int depth) {
  char buf[64]; int n;
  switch (v.t) {
    case T_INT: n = rt_fmt_int(buf, v.u.i); rt_write(buf, n); break;
    case T_DBL: n = rt_fmt_dbl(buf, v.u.d, -1); rt_write(buf, n); break;
    case T_STR: rt_write(STR(v)->s, STR(v)->n); break;
    case T_NIL: rt_write("nil", 3); break;
    case T_FN: rt_write("<함수>", 8); break;
    case T_LIST: {
      List *l = LST(v);
      int rows = depth == 0 && l->n && l->a[0].t == T_LIST;
      for (int i = 0; i < l->n; i++) {
        if (i) rt_putc(rows ? '\n' : ' ');
        if (depth > 0 && l->a[i].t == T_LIST) { rt_putc('['); rt_print_inner(l->a[i], depth + 1); rt_putc(']'); }
        else rt_print_inner(l->a[i], depth + 1);
      }
      break;
    }
    case T_SET: case T_MAP: {
      Tree *t = v.u.p; List *tmp = mklist(t->n);
      tr_collect(t->root, tmp, v.t == T_SET);
      for (int i = 0; i < tmp->n; i++) {
        if (i) rt_putc(v.t == T_MAP ? '\n' : ' ');
        if (v.t == T_MAP) { rt_print_inner(LST(tmp->a[i])->a[0], 1); rt_putc(' '); rt_print_inner(LST(tmp->a[i])->a[1], 1); }
        else rt_print_inner(tmp->a[i], depth + 1);
      }
      break;
    }
    case T_PQ: { Pq *q = v.u.p; for (int i = 0; i < q->h->n; i++) { if (i) rt_putc(' '); rt_print_inner(q->h->a[i], depth + 1); } break; }
    case T_DEQ: { Deq *d = v.u.p; for (int i = 0; i < d->n; i++) { if (i) rt_putc(' '); rt_print_inner(d->a[(d->head + i) % d->cap], depth + 1); } break; }
  }
}
static V rt_fmtp(V a, int prec) {
  if (!isnum(a)) rt_type_error("소수점 자리 맞추기는 숫자에만 쓸 수 있어요", a);
  char buf[400]; int n = rt_fmt_dbl(buf, todbl(a), prec);
  return vstr(buf, n);
}

/* ------------------------------------------------------------------ */
/* arithmetic                                                          */
/* ------------------------------------------------------------------ */
static V rt_concat(V a, V b) {
  a = rt_tostr(a); b = rt_tostr(b);
  Str *x = STR(a), *y = STR(b);
  Str *r = rt_alloc(sizeof(Str)); r->n = x->n + y->n; r->cap = r->n + 1; r->s = rt_alloc(r->cap);
  memcpy(r->s, x->s, x->n); memcpy(r->s + x->n, y->s, y->n);
  return vobj(T_STR, r);
}
static V rt_add(V a, V b) {
  if (a.t == T_INT && b.t == T_INT) return vi(a.u.i + b.u.i);
  if (isnum(a) && isnum(b)) return vd(todbl(a) + todbl(b));
  if (a.t == T_STR || b.t == T_STR) return rt_concat(a, b);
  if (a.t == T_LIST && b.t == T_LIST) {
    List *x = LST(a), *y = LST(b); V r = vlist(x->n + y->n);
    for (int i = 0; i < x->n; i++) lpush(LST(r), x->a[i]);
    for (int i = 0; i < y->n; i++) lpush(LST(r), y->a[i]);
    return r;
  }
  rt_type_error("+ 를 쓸 수 없는 값이에요", isnum(a) ? b : a);
}
static V rt_sub(V a, V b) {
  if (a.t == T_INT && b.t == T_INT) return vi(a.u.i - b.u.i);
  if (isnum(a) && isnum(b)) return vd(todbl(a) - todbl(b));
  if (a.t == T_STR && b.t == T_STR && STR(a)->n == 1 && STR(b)->n == 1)
    return vi((unsigned char)STR(a)->s[0] - (unsigned char)STR(b)->s[0]);   /* "7" - "0" == 7 */
  rt_type_error("- 를 쓸 수 없는 값이에요", isnum(a) ? b : a);
}
static V rt_mul(V a, V b) {
  if (a.t == T_INT && b.t == T_INT) return vi(a.u.i * b.u.i);
  if (isnum(a) && isnum(b)) return vd(todbl(a) * todbl(b));
  if (a.t == T_STR && b.t == T_INT) {
    Str *x = STR(a); i64 k = b.u.i < 0 ? 0 : b.u.i;
    Str *r = rt_alloc(sizeof(Str)); r->n = (int)(x->n * k); r->cap = r->n + 1; r->s = rt_alloc(r->cap);
    for (i64 i = 0; i < k; i++) memcpy(r->s + i * x->n, x->s, x->n);
    return vobj(T_STR, r);
  }
  rt_type_error("* 를 쓸 수 없는 값이에요", isnum(a) ? b : a);
}
static V rt_div(V a, V b) {
  if (a.t == T_INT && b.t == T_INT) {
    if (!b.u.i) rt_error("0으로 나눴어요");
    return vi(a.u.i / b.u.i);
  }
  if (isnum(a) && isnum(b)) return vd(todbl(a) / todbl(b));
  rt_type_error("/ 를 쓸 수 없는 값이에요", isnum(a) ? b : a);
}
static V rt_mod(V a, V b) {
  if (a.t == T_INT && b.t == T_INT) {
    if (!b.u.i) rt_error("0으로 나눈 나머지를 구했어요");
    return vi(a.u.i % b.u.i);
  }
  if (isnum(a) && isnum(b)) {
    double x = todbl(a), y = todbl(b), q = x / y;
    q = q < 0 ? -RT_FLOOR(-q) : RT_FLOOR(q);
    return vd(x - q * y);
  }
  rt_type_error("% 를 쓸 수 없는 값이에요", isnum(a) ? b : a);
}
static V rt_neg(V a) {
  if (a.t == T_INT) return vi(-a.u.i);
  if (a.t == T_DBL) return vd(-a.u.d);
  rt_type_error("- 를 붙일 수 없는 값이에요", a);
}
#define RT_INTOP(name, op, sym) static V name(V a, V b) { \
  if (a.t != T_INT || b.t != T_INT) rt_type_error(sym " 는 정수끼리만 쓸 수 있어요", a.t != T_INT ? a : b); \
  return vi(a.u.i op b.u.i); }
RT_INTOP(rt_band, &, "&")
RT_INTOP(rt_bor, |, "|")
RT_INTOP(rt_bxor, ^, "^")
static V rt_shl(V a, V b) { if (a.t != T_INT || b.t != T_INT) rt_error("<< 는 정수끼리만 쓸 수 있어요"); return vi((i64)((unsigned long long)a.u.i << (b.u.i & 63))); }
static V rt_shr(V a, V b) { if (a.t != T_INT || b.t != T_INT) rt_error(">> 는 정수끼리만 쓸 수 있어요"); return vi(a.u.i >> (b.u.i & 63)); }
static V rt_bnot(V a) { if (a.t != T_INT) rt_type_error("~ 는 정수에만 쓸 수 있어요", a); return vi(~a.u.i); }
static V rt_not(V a) { return vi(!rt_truthy(a)); }
static V rt_eq(V a, V b) { return vi(rt_cmp(a, b) == 0); }
static V rt_ne(V a, V b) { return vi(rt_cmp(a, b) != 0); }
static V rt_lt(V a, V b) { return vi(rt_cmp(a, b) < 0); }
static V rt_le(V a, V b) { return vi(rt_cmp(a, b) <= 0); }
static V rt_gt(V a, V b) { return vi(rt_cmp(a, b) > 0); }
static V rt_ge(V a, V b) { return vi(rt_cmp(a, b) >= 0); }

/* ------------------------------------------------------------------ */
/* containers                                                          */
/* ------------------------------------------------------------------ */
static int rt_size(V a) {
  switch (a.t) {
    case T_STR: return STR(a)->n;
    case T_LIST: return LST(a)->n;
    case T_MAP: case T_SET: return ((Tree *)a.u.p)->n;
    case T_PQ: return ((Pq *)a.u.p)->h->n;
    case T_DEQ: return ((Deq *)a.u.p)->n;
    default: rt_type_error("길이를 잴 수 없는 값이에요", a);
  }
}
static int norm_index(i64 i, int n) {
  if (i < 0) i += n;
  if (i < 0 || i >= n) {
    char buf[120]; int k = 0; const char *s = "범위를 벗어난 위치예요: ";
    while (*s) buf[k++] = *s++;
    k += rt_fmt_int(buf + k, i);
    s = " (길이 "; while (*s) buf[k++] = *s++;
    k += rt_fmt_int(buf + k, n); buf[k++] = ')'; buf[k] = 0;
    rt_error(buf);
  }
  return (int)i;
}
static V rt_index(V c, V i) {
  switch (c.t) {
    case T_LIST: return LST(c)->a[norm_index(toint(i, "위치는 정수여야 해요"), LST(c)->n)];
    case T_STR: { int k = norm_index(toint(i, "위치는 정수여야 해요"), STR(c)->n); return vstr(STR(c)->s + k, 1); }
    case T_MAP: { TN *f = tr_find(((Tree *)c.u.p)->root, i); return f ? f->v : vi(0); }
    case T_DEQ: { Deq *d = c.u.p; int k = norm_index(toint(i, "위치는 정수여야 해요"), d->n); return d->a[(d->head + k) % d->cap]; }
    default: rt_type_error("[ ] 로 꺼낼 수 없는 값이에요", c);
  }
}
static V *rt_ref(V c, V i) {
  switch (c.t) {
    case T_LIST: return &LST(c)->a[norm_index(toint(i, "위치는 정수여야 해요"), LST(c)->n)];
    case T_MAP: return &tr_insert(c.u.p, i, vi(0))->v;
    case T_DEQ: { Deq *d = c.u.p; int k = norm_index(toint(i, "위치는 정수여야 해요"), d->n); return &d->a[(d->head + k) % d->cap]; }
    case T_STR: rt_error("문자열의 글자는 바꿀 수 없어요 (새 문자열을 만들어 주세요)");
    default: rt_type_error("[ ] 로 값을 넣을 수 없는 값이에요", c);
  }
}
static V rt_zeros(i64 *dims, int nd) {
  if (dims[0] < 0) rt_error("길이가 음수예요");
  V r = vlist((int)dims[0]);
  for (i64 i = 0; i < dims[0]; i++) lpush(LST(r), nd > 1 ? rt_zeros(dims + 1, nd - 1) : vi(0));
  return r;
}
static V rt_readdims(i64 *dims, int nd) {
  if (dims[0] < 0) rt_error("길이가 음수예요");
  V r = vlist((int)dims[0]);
  for (i64 i = 0; i < dims[0]; i++) lpush(LST(r), nd > 1 ? rt_readdims(dims + 1, nd - 1) : rt_read());
  return r;
}
static V rt_listlit(V *a, int n) { V r = vlist(n); for (int i = 0; i < n; i++) lpush(LST(r), a[i]); return r; }

/* deque */
static Deq *mkdeq(void) { Deq *d = rt_alloc(sizeof(Deq)); d->cap = 8; d->a = rt_alloc(sizeof(V) * 8); return d; }
static void deq_push(Deq *d, V x) {
  if (d->n == d->cap) {
    V *na = rt_alloc(sizeof(V) * d->cap * 2);
    for (int i = 0; i < d->n; i++) na[i] = d->a[(d->head + i) % d->cap];
    d->a = na; d->head = 0; d->cap *= 2;
  }
  d->a[(d->head + d->n) % d->cap] = x; d->n++;
}

/* priority queue */
static V rt_apply(V fn, V *args, int n);
static int pq_less(Pq *q, V a, V b) {
  if (q->mode == 0) return rt_cmp(a, b) < 0;
  if (q->mode == 1) return rt_cmp(a, b) > 0;
  V args[2] = { a, b }; return rt_truthy(rt_apply(q->cmp, args, 2));
}
static void pq_push(Pq *q, V x) {
  lpush(q->h, x); int i = q->h->n - 1; V *h = q->h->a;
  while (i > 0) { int p = (i - 1) / 2; if (!pq_less(q, h[p], h[i])) break; V t = h[p]; h[p] = h[i]; h[i] = t; i = p; }
}
static V pq_pop(Pq *q) {
  if (!q->h->n) rt_error("빈 우선순위 큐에서 꺼냈어요");
  V *h = q->h->a; V top = h[0]; h[0] = h[--q->h->n]; int n = q->h->n, i = 0;
  for (;;) {
    int l = 2 * i + 1, r = l + 1, m = i;
    if (l < n && pq_less(q, h[m], h[l])) m = l;
    if (r < n && pq_less(q, h[m], h[r])) m = r;
    if (m == i) break;
    V t = h[m]; h[m] = h[i]; h[i] = t; i = m;
  }
  return top;
}

/* += and -= on any value */
static void rt_addto(V *lhs, V rhs) {
  switch (lhs->t) {
    case T_LIST: lpush(LST(*lhs), rhs); return;
    case T_SET: tr_insert(lhs->u.p, rhs, vi(0)); return;
    case T_PQ: pq_push(lhs->u.p, rhs); return;
    case T_DEQ: deq_push(lhs->u.p, rhs); return;
    case T_MAP: rt_error("맵에는 m[키] = 값 으로 넣어요");
    default: *lhs = rt_add(*lhs, rhs);
  }
}
static void rt_subfrom(V *lhs, V rhs) {
  if (lhs->t == T_SET || lhs->t == T_MAP) { tr_erase(lhs->u.p, rhs); return; }
  *lhs = rt_sub(*lhs, rhs);
}

/* foreach source: list of items */
static V rt_iterlist(V c) {
  switch (c.t) {
    case T_LIST: { V r = vlist(LST(c)->n); for (int i = 0; i < LST(c)->n; i++) lpush(LST(r), LST(c)->a[i]); return r; }
    case T_STR: { V r = vlist(STR(c)->n); for (int i = 0; i < STR(c)->n; i++) lpush(LST(r), vstr(STR(c)->s + i, 1)); return r; }
    case T_SET: { V r = vlist(((Tree *)c.u.p)->n); tr_collect(((Tree *)c.u.p)->root, LST(r), 1); return r; }
    case T_MAP: { V r = vlist(((Tree *)c.u.p)->n); tr_collect(((Tree *)c.u.p)->root, LST(r), 0); return r; }
    case T_DEQ: { Deq *d = c.u.p; V r = vlist(d->n); for (int i = 0; i < d->n; i++) lpush(LST(r), d->a[(d->head + i) % d->cap]); return r; }
    case T_INT: { V r = vlist((int)(c.u.i > 0 ? c.u.i : 0)); for (i64 i = 0; i < c.u.i; i++) lpush(LST(r), vi(i)); return r; }
    default: rt_type_error("하나씩 꺼내 돌 수 없는 값이에요", c);
  }
}

/* ------------------------------------------------------------------ */
/* functions as values                                                 */
/* ------------------------------------------------------------------ */
static V rt_bi(int id, V *a, int n);
static V rt_mkfn(void *fp, int arity) { Fn *f = rt_alloc(sizeof(Fn)); f->bi = -1; f->fp = fp; f->arity = arity; return vobj(T_FN, f); }
static V rt_mkfn_ast(void *ast, int arity) { Fn *f = rt_alloc(sizeof(Fn)); f->bi = -1; f->ast = ast; f->arity = arity; return vobj(T_FN, f); }
static V rt_mkfn_bi(int id) { Fn *f = rt_alloc(sizeof(Fn)); f->bi = id; f->arity = -1; return vobj(T_FN, f); }
typedef V (*F0)(void); typedef V (*F1)(V); typedef V (*F2)(V, V); typedef V (*F3)(V, V, V);
typedef V (*F4)(V, V, V, V); typedef V (*F5)(V, V, V, V, V); typedef V (*F6)(V, V, V, V, V, V);
static V rt_apply(V fn, V *a, int n) {
  if (fn.t != T_FN) rt_type_error("함수가 아닌 값을 호출했어요", fn);
  Fn *f = fn.u.p;
  if (f->bi >= 0) return rt_bi(f->bi, a, n);
  if (f->arity != n) rt_error("함수에 넘긴 값의 개수가 맞지 않아요");
  if (f->ast) { if (!rt_hook_apply) rt_error("함수를 실행할 수 없어요"); return rt_hook_apply(f->ast, a, n); }
  switch (n) {
    case 0: return ((F0)f->fp)();
    case 1: return ((F1)f->fp)(a[0]);
    case 2: return ((F2)f->fp)(a[0], a[1]);
    case 3: return ((F3)f->fp)(a[0], a[1], a[2]);
    case 4: return ((F4)f->fp)(a[0], a[1], a[2], a[3]);
    case 5: return ((F5)f->fp)(a[0], a[1], a[2], a[3], a[4]);
    case 6: return ((F6)f->fp)(a[0], a[1], a[2], a[3], a[4], a[5]);
  }
  rt_error("값으로 넘기는 함수는 매개변수가 6개까지예요");
}

/* ------------------------------------------------------------------ */
/* sorting (stable merge sort)                                         */
/* ------------------------------------------------------------------ */
static int sort_mode; static V sort_fn;
static int sort_less(V a, V b) {
  if (sort_mode == 0) return rt_cmp(a, b) < 0;
  if (sort_mode == 1) return rt_cmp(a, b) > 0;
  V args[2] = { a, b }; return rt_truthy(rt_apply(sort_fn, args, 2));
}
static void msort(V *a, V *tmp, int n) {
  if (n < 2) return;
  if (n <= 16) {
    for (int i = 1; i < n; i++) { V x = a[i]; int j = i - 1; while (j >= 0 && sort_less(x, a[j])) { a[j + 1] = a[j]; j--; } a[j + 1] = x; }
    return;
  }
  int m = n / 2; msort(a, tmp, m); msort(a + m, tmp, n - m);
  int i = 0, j = m, k = 0;
  while (i < m && j < n) tmp[k++] = sort_less(a[j], a[i]) ? a[j++] : a[i++];
  while (i < m) tmp[k++] = a[i++];
  while (j < n) tmp[k++] = a[j++];
  memcpy(a, tmp, sizeof(V) * n);
}
static V rt_sort(V v, int mode, V fn) {
  if (v.t == T_STR) {   /* sort characters of a string */
    Str *s = STR(v); V r = vstr(s->s, s->n); char *c = STR(r)->s;
    for (int i = 1; i < s->n; i++) { char x = c[i]; int j = i - 1; while (j >= 0 && (mode == 1 ? x > c[j] : x < c[j])) { c[j + 1] = c[j]; j--; } c[j + 1] = x; }
    return r;
  }
  if (v.t != T_LIST) rt_type_error("정렬은 리스트에만 쓸 수 있어요", v);
  int pm = sort_mode; V pf = sort_fn;
  sort_mode = mode; sort_fn = fn;
  List *l = LST(v); V *tmp = rt_alloc(sizeof(V) * (l->n + 1));
  msort(l->a, tmp, l->n);
  sort_mode = pm; sort_fn = pf;
  return v;
}

/* ------------------------------------------------------------------ */
/* built-in functions                                                  */
/* ------------------------------------------------------------------ */
enum {
  BI_M, BI_m, BI_G, BI_g, BI_S, BI_R, BI_U, BI_C, BI_N, BI_L, BI_H, BI_B,
  BI_P, BI_Sv, BI_Pw, BI_Cr, BI_Fc, BI_Ab, BI_Sq, BI_A, BI_I, BI_D, BI_St, BI_O, BI_Ch,
  BI_Po, BI_T, BI_In, BI_Ps, BI_Lis, BI_Lcs, BI_Kn, BI_Pal, BI_Kmp,
  BI_Bf, BI_Df, BI_Dj, BI_Fw, BI_Tp, BI_Uf, BI_Fd, BI_Un, BI_Kr,
  BI_Q, BI_PQ, BI_ST, BI_MP, BI_Rl,
  BI_SORT, BI_SORTD, BI_SZ, BI_SUB, BI_FIND, BI_REPL,
  BI_COUNT
};
static const char *const rt_bi_names[BI_COUNT] = {
  "M", "m", "G", "g", "S", "R", "U", "C", "N", "L", "H", "B",
  "P", "Sv", "Pw", "Cr", "Fc", "Ab", "Sq", "A", "I", "D", "St", "O", "Ch",
  "Po", "T", "In", "Ps", "Lis", "Lcs", "Kn", "Pal", "Kmp",
  "Bf", "Df", "Dj", "Fw", "Tp", "Uf", "Fd", "Un", "Kr",
  "Q", "PQ", "ST", "MP", "Rl",
  "'", "''", "s'", "s''", "s'''", "s''''"
};

static void need(int n, int lo, int hi, int id) {
  if (n < lo || n > hi) {
    char buf[120]; int k = 0; const char *s = rt_bi_names[id];
    while (*s) buf[k++] = *s++;
    s = " 에 넘긴 값의 개수가 맞지 않아요"; while (*s) buf[k++] = *s++;
    buf[k] = 0; rt_error(buf);
  }
}
static List *as_list(V v, const char *what) { if (v.t != T_LIST) rt_type_error(what, v); return LST(v); }
static i64 gcd64(i64 a, i64 b) { if (a < 0) a = -a; if (b < 0) b = -b; while (b) { i64 t = a % b; a = b; b = t; } return a; }
static i64 mulmod(i64 a, i64 b, i64 m) {
  a %= m; b %= m; if (a < 0) a += m; if (b < 0) b += m;
  if (m <= 3037000499LL) return a * b % m;
  i64 r = 0;
  while (b) { if (b & 1) { r += a; if (r >= m) r -= m; } a += a; if (a >= m) a -= m; b >>= 1; }
  return r;
}
static i64 powmod(i64 a, i64 e, i64 m) {
  i64 r = 1 % m; a %= m; if (a < 0) a += m;
  while (e > 0) { if (e & 1) r = mulmod(r, a, m); a = mulmod(a, a, m); e >>= 1; }
  return r;
}
static V copy_deep(V x) {
  if (x.t != T_LIST) return x;
  V r = vlist(LST(x)->n); for (int i = 0; i < LST(x)->n; i++) lpush(LST(r), copy_deep(LST(x)->a[i]));
  return r;
}
static V extreme(V *a, int n, int want_max) {
  if (n == 1) {
    V x = a[0];
    if (x.t == T_LIST) { List *l = LST(x); if (!l->n) rt_error("빈 리스트의 최댓값/최솟값은 없어요"); V b = l->a[0]; for (int i = 1; i < l->n; i++) if ((rt_cmp(l->a[i], b) > 0) == want_max && rt_cmp(l->a[i], b)) b = l->a[i]; return b; }
    if (x.t == T_SET) { TN *t = want_max ? tr_max(((Tree *)x.u.p)->root) : tr_min(((Tree *)x.u.p)->root); if (!t) rt_error("빈 집합의 최댓값/최솟값은 없어요"); return t->k; }
    return x;
  }
  V b = a[0]; for (int i = 1; i < n; i++) { int c = rt_cmp(a[i], b); if (c && (c > 0) == want_max) b = a[i]; }
  return b;
}
static List *edge_list(V v) { return as_list(v, "그래프는 인접 리스트(리스트의 리스트)여야 해요"); }

static V rt_bi(int id, V *a, int n) {
  switch (id) {
    case BI_M: if (n < 1) need(n, 1, 99, id); return extreme(a, n, 1);
    case BI_m: if (n < 1) need(n, 1, 99, id); return extreme(a, n, 0);
    case BI_G: need(n, 2, 2, id); return vi(gcd64(toint(a[0], "G 는 정수에만"), toint(a[1], "G 는 정수에만")));
    case BI_g: { need(n, 2, 2, id); i64 x = toint(a[0], "g 는 정수에만"), y = toint(a[1], "g 는 정수에만"); if (!x || !y) return vi(0); i64 r = x / gcd64(x, y) * y; return vi(r < 0 ? -r : r); }
    case BI_S: {
      need(n, 1, 1, id); List *l = as_list(a[0], "S 는 리스트의 합이에요");
      V s = vi(0); for (int i = 0; i < l->n; i++) s = rt_add(s, l->a[i]); return s;
    }
    case BI_R: {
      need(n, 1, 1, id);
      if (a[0].t == T_STR) { Str *s = STR(a[0]); V r = vstr(s->s, s->n); for (int i = 0; i < s->n; i++) STR(r)->s[i] = s->s[s->n - 1 - i]; return r; }
      List *l = as_list(a[0], "R 은 리스트나 문자열을 뒤집어요");
      for (int i = 0, j = l->n - 1; i < j; i++, j--) { V t = l->a[i]; l->a[i] = l->a[j]; l->a[j] = t; }
      return a[0];
    }
    case BI_U: {
      need(n, 1, 1, id); List *l = as_list(a[0], "U 는 리스트에만 쓸 수 있어요");
      rt_sort(a[0], 0, vi(0)); int k = 0;
      for (int i = 0; i < l->n; i++) if (!k || rt_cmp(l->a[i], l->a[k - 1])) l->a[k++] = l->a[i];
      l->n = k; return a[0];
    }
    case BI_C: {
      need(n, 2, 2, id); i64 c = 0;
      if (a[0].t == T_STR) {
        V t = rt_tostr(a[1]); Str *s = STR(a[0]), *p = STR(t);
        if (p->n) for (int i = 0; i + p->n <= s->n; i++) if (!memcmp(s->s + i, p->s, p->n)) c++;
        return vi(c);
      }
      List *l = as_list(a[0], "C 는 리스트나 문자열에서 세요");
      for (int i = 0; i < l->n; i++) if (!rt_cmp(l->a[i], a[1])) c++;
      return vi(c);
    }
    case BI_N: {
      need(n, 1, 1, id); List *l = as_list(a[0], "N 은 리스트의 다음 순열이에요");
      int i = l->n - 2; while (i >= 0 && rt_cmp(l->a[i], l->a[i + 1]) >= 0) i--;
      if (i < 0) { for (int x = 0, y = l->n - 1; x < y; x++, y--) { V t = l->a[x]; l->a[x] = l->a[y]; l->a[y] = t; } return vi(0); }
      int j = l->n - 1; while (rt_cmp(l->a[j], l->a[i]) <= 0) j--;
      V t = l->a[i]; l->a[i] = l->a[j]; l->a[j] = t;
      for (int x = i + 1, y = l->n - 1; x < y; x++, y--) { V u = l->a[x]; l->a[x] = l->a[y]; l->a[y] = u; }
      return vi(1);
    }
    case BI_L: case BI_H: {
      need(n, 2, 2, id); int strict = id == BI_H;
      if (a[0].t == T_SET || a[0].t == T_MAP) { TN *t = tr_lower(((Tree *)a[0].u.p)->root, a[1], strict); return t ? t->k : vnil(); }
      List *l = as_list(a[0], "L/H 는 정렬된 리스트나 집합에 써요");
      int lo = 0, hi = l->n;
      while (lo < hi) { int mid = (lo + hi) / 2; int c = rt_cmp(l->a[mid], a[1]); if (c < 0 || (strict && c == 0)) lo = mid + 1; else hi = mid; }
      return vi(lo);
    }
    case BI_B: {
      need(n, 2, 2, id);
      if (a[0].t == T_SET || a[0].t == T_MAP) return vi(tr_find(((Tree *)a[0].u.p)->root, a[1]) != 0);
      List *l = as_list(a[0], "B 는 정렬된 리스트에서 찾아요");
      int lo = 0, hi = l->n; while (lo < hi) { int mid = (lo + hi) / 2; if (rt_cmp(l->a[mid], a[1]) < 0) lo = mid + 1; else hi = mid; }
      return vi(lo < l->n && !rt_cmp(l->a[lo], a[1]));
    }
    case BI_P: {
      need(n, 1, 1, id); i64 x = toint(a[0], "P 는 정수에만");
      if (x < 2) return vi(0); if (x < 4) return vi(1); if (x % 2 == 0 || x % 3 == 0) return vi(0);
      for (i64 d = 5; d * d <= x; d += 6) if (x % d == 0 || x % (d + 2) == 0) return vi(0);
      return vi(1);
    }
    case BI_Sv: {
      need(n, 1, 1, id); i64 x = toint(a[0], "Sv 는 정수에만"); V r = vlist(16);
      if (x < 2) return r;
      if (x > 100000000) rt_error("Sv 는 1억까지만 돼요");
      unsigned char *c = rt_alloc((size_t)x + 1);
      for (i64 i = 2; i <= x; i++) if (!c[i]) { lpush(LST(r), vi(i)); for (i64 j = i * i; j <= x; j += i) c[j] = 1; }
      return r;
    }
    case BI_Pw: {
      need(n, 2, 3, id); i64 b = toint(a[0], "Pw 는 정수에만"), e = toint(a[1], "Pw 는 정수에만");
      if (n == 3) { i64 m = toint(a[2], "Pw 는 정수에만"); if (m <= 0) rt_error("Pw 의 모듈러는 양수여야 해요"); return vi(powmod(b, e, m)); }
      if (e < 0) { double r = 1; for (i64 i = 0; i < -e; i++) r /= (double)b; return vd(r); }
      i64 r = 1; while (e > 0) { if (e & 1) r *= b; b *= b; e >>= 1; } return vi(r);
    }
    case BI_Cr: {
      need(n, 2, 3, id); i64 N = toint(a[0], "Cr 은 정수에만"), K = toint(a[1], "Cr 은 정수에만");
      if (K < 0 || K > N) return vi(0); if (K > N - K) K = N - K;
      if (n == 3) {
        i64 m = toint(a[2], "Cr 은 정수에만"), num = 1, den = 1;
        for (i64 i = 0; i < K; i++) { num = mulmod(num, N - i, m); den = mulmod(den, i + 1, m); }
        return vi(mulmod(num, powmod(den, m - 2, m), m));
      }
      i64 r = 1; for (i64 i = 0; i < K; i++) r = r / (i + 1) * (N - i) + r % (i + 1) * (N - i) / (i + 1);
      return vi(r);
    }
    case BI_Fc: {
      need(n, 1, 1, id); i64 x = toint(a[0], "Fc 는 정수에만"); V r = vlist(8);
      for (i64 d = 2; d * d <= x; d++) while (x % d == 0) { lpush(LST(r), vi(d)); x /= d; }
      if (x > 1) lpush(LST(r), vi(x));
      return r;
    }
    case BI_Ab: need(n, 1, 1, id); if (a[0].t == T_INT) return vi(a[0].u.i < 0 ? -a[0].u.i : a[0].u.i); if (a[0].t == T_DBL) return vd(a[0].u.d < 0 ? -a[0].u.d : a[0].u.d); rt_type_error("Ab 는 숫자에만", a[0]);
    case BI_Sq: need(n, 1, 1, id); if (!isnum(a[0])) rt_type_error("Sq 는 숫자에만", a[0]); return vd(RT_SQRT(todbl(a[0])));
    case BI_A: {
      need(n, 2, 3, id);
      if (n == 2) { i64 k = toint(a[0], "A 의 길이는 정수예요"); V r = vlist((int)k); for (i64 i = 0; i < k; i++) lpush(LST(r), copy_deep(a[1])); return r; }
      i64 k = toint(a[0], "A 의 길이는 정수예요"), k2 = toint(a[1], "A 의 길이는 정수예요"); V r = vlist((int)k);
      for (i64 i = 0; i < k; i++) { V row = vlist((int)k2); for (i64 j = 0; j < k2; j++) lpush(LST(row), copy_deep(a[2])); lpush(LST(r), row); }
      return r;
    }
    case BI_I: {
      need(n, 1, 1, id);
      if (a[0].t == T_STR) { i64 iv; double dv; int k = rt_parse_num(STR(a[0])->s, STR(a[0])->n, &iv, &dv); if (k == 1) return vi(iv); if (k == 2) return vi((i64)dv); rt_error("정수로 바꿀 수 없는 문자열이에요"); }
      return vi(toint(a[0], "I 로 바꿀 수 없는 값이에요"));
    }
    case BI_D: {
      need(n, 1, 1, id);
      if (a[0].t == T_STR) { i64 iv; double dv; int k = rt_parse_num(STR(a[0])->s, STR(a[0])->n, &iv, &dv); if (k == 1) return vd((double)iv); if (k == 2) return vd(dv); rt_error("실수로 바꿀 수 없는 문자열이에요"); }
      if (!isnum(a[0])) rt_type_error("D 로 바꿀 수 없는 값이에요", a[0]); return vd(todbl(a[0]));
    }
    case BI_St: need(n, 1, 1, id); return rt_tostr(a[0]);
    case BI_O: need(n, 1, 1, id); if (a[0].t != T_STR || !STR(a[0])->n) rt_type_error("O 는 글자의 코드값이에요", a[0]); return vi((unsigned char)STR(a[0])->s[0]);
    case BI_Ch: { need(n, 1, 1, id); char c = (char)toint(a[0], "Ch 는 정수에만"); return vstr(&c, 1); }
    case BI_Po: {
      need(n, 1, 1, id); V x = a[0];
      if (x.t == T_LIST) { if (!LST(x)->n) rt_error("빈 리스트에서 꺼냈어요"); return LST(x)->a[--LST(x)->n]; }
      if (x.t == T_DEQ) { Deq *d = x.u.p; if (!d->n) rt_error("빈 큐에서 꺼냈어요"); V r = d->a[d->head]; d->head = (d->head + 1) % d->cap; d->n--; return r; }
      if (x.t == T_PQ) return pq_pop(x.u.p);
      if (x.t == T_SET) { TN *t = tr_min(((Tree *)x.u.p)->root); if (!t) rt_error("빈 집합에서 꺼냈어요"); V k = t->k; tr_erase(x.u.p, k); return k; }
      rt_type_error("Po 로 꺼낼 수 없는 값이에요", x);
    }
    case BI_T: {
      need(n, 1, 1, id); V x = a[0];
      if (x.t == T_LIST) { if (!LST(x)->n) rt_error("빈 리스트예요"); return LST(x)->a[LST(x)->n - 1]; }
      if (x.t == T_DEQ) { Deq *d = x.u.p; if (!d->n) rt_error("빈 큐예요"); return d->a[d->head]; }
      if (x.t == T_PQ) { Pq *q = x.u.p; if (!q->h->n) rt_error("빈 우선순위 큐예요"); return q->h->a[0]; }
      if (x.t == T_SET) { TN *t = tr_min(((Tree *)x.u.p)->root); if (!t) rt_error("빈 집합이에요"); return t->k; }
      rt_type_error("T 로 볼 수 없는 값이에요", x);
    }
    case BI_In: {
      need(n, 2, 2, id); V x = a[0];
      if (x.t == T_SET || x.t == T_MAP) return vi(tr_find(((Tree *)x.u.p)->root, a[1]) != 0);
      if (x.t == T_STR) { V t = rt_tostr(a[1]); Str *s = STR(x), *p = STR(t); for (int i = 0; i + p->n <= s->n; i++) if (!memcmp(s->s + i, p->s, p->n)) return vi(1); return vi(0); }
      if (x.t == T_LIST) { for (int i = 0; i < LST(x)->n; i++) if (!rt_cmp(LST(x)->a[i], a[1])) return vi(1); return vi(0); }
      rt_type_error("In 은 집합·맵·리스트·문자열에 써요", x);
    }
    case BI_Ps: {
      need(n, 1, 1, id); List *l = as_list(a[0], "Ps 는 리스트의 누적 합이에요");
      V r = vlist(l->n + 1); V s = vi(0); lpush(LST(r), s);
      for (int i = 0; i < l->n; i++) { s = rt_add(s, l->a[i]); lpush(LST(r), s); }
      return r;
    }
    case BI_Lis: {
      need(n, 1, 1, id); List *l = as_list(a[0], "Lis 는 리스트에 써요");
      V *t = rt_alloc(sizeof(V) * (l->n + 1)); int len = 0;
      for (int i = 0; i < l->n; i++) {
        int lo = 0, hi = len; while (lo < hi) { int mid = (lo + hi) / 2; if (rt_cmp(t[mid], l->a[i]) < 0) lo = mid + 1; else hi = mid; }
        t[lo] = l->a[i]; if (lo == len) len++;
      }
      return vi(len);
    }
    case BI_Lcs: {
      need(n, 2, 2, id);
      V x = a[0].t == T_STR ? rt_iterlist(a[0]) : a[0], y = a[1].t == T_STR ? rt_iterlist(a[1]) : a[1];
      List *p = as_list(x, "Lcs 는 리스트나 문자열 두 개예요"), *q = as_list(y, "Lcs 는 리스트나 문자열 두 개예요");
      int *dp = rt_alloc(sizeof(int) * (q->n + 1)), *nx = rt_alloc(sizeof(int) * (q->n + 1));
      for (int i = 1; i <= p->n; i++) {
        for (int j = 1; j <= q->n; j++) nx[j] = !rt_cmp(p->a[i - 1], q->a[j - 1]) ? dp[j - 1] + 1 : (dp[j] > nx[j - 1] ? dp[j] : nx[j - 1]);
        int *t = dp; dp = nx; nx = t;
      }
      return vi(dp[q->n]);
    }
    case BI_Kn: {
      need(n, 3, 3, id);
      List *w = as_list(a[0], "Kn(무게들, 가치들, 용량)"), *v = as_list(a[1], "Kn(무게들, 가치들, 용량)");
      i64 cap = toint(a[2], "Kn 용량은 정수예요");
      if (cap < 0) return vi(0);
      i64 *dp = rt_alloc(sizeof(i64) * (size_t)(cap + 1));
      for (int i = 0; i < w->n && i < v->n; i++) {
        i64 wi = toint(w->a[i], "무게는 정수예요"), val = toint(v->a[i], "가치는 정수예요");
        for (i64 c = cap; c >= wi; c--) if (dp[c - wi] + val > dp[c]) dp[c] = dp[c - wi] + val;
      }
      return vi(dp[cap]);
    }
    case BI_Pal: {
      need(n, 1, 1, id);
      if (a[0].t == T_STR) { Str *s = STR(a[0]); for (int i = 0, j = s->n - 1; i < j; i++, j--) if (s->s[i] != s->s[j]) return vi(0); return vi(1); }
      List *l = as_list(a[0], "Pal 은 문자열이나 리스트에 써요");
      for (int i = 0, j = l->n - 1; i < j; i++, j--) if (rt_cmp(l->a[i], l->a[j])) return vi(0);
      return vi(1);
    }
    case BI_Kmp: {
      need(n, 2, 2, id);
      if (a[0].t != T_STR || a[1].t != T_STR) rt_error("Kmp(문자열, 찾을 문자열)");
      Str *s = STR(a[0]), *p = STR(a[1]); V r = vlist(4);
      if (!p->n) return r;
      int *f = rt_alloc(sizeof(int) * p->n);
      for (int i = 1, k = 0; i < p->n; i++) { while (k && p->s[i] != p->s[k]) k = f[k - 1]; if (p->s[i] == p->s[k]) k++; f[i] = k; }
      for (int i = 0, k = 0; i < s->n; i++) {
        while (k && s->s[i] != p->s[k]) k = f[k - 1];
        if (s->s[i] == p->s[k]) k++;
        if (k == p->n) { lpush(LST(r), vi(i - p->n + 1)); k = f[k - 1]; }
      }
      return r;
    }
    case BI_Bf: case BI_Df: {
      need(n, 2, 2, id); List *g = edge_list(a[0]); int N = g->n; i64 s = toint(a[1], "시작점은 정수예요");
      if (s < 0 || s >= N) rt_error("시작점이 그래프 밖에 있어요");
      V out = vlist(N);
      if (id == BI_Bf) {
        for (int i = 0; i < N; i++) lpush(LST(out), vi(-1));
        int *qu = rt_alloc(sizeof(int) * (N + 1)), h = 0, t = 0; qu[t++] = (int)s; LST(out)->a[s] = vi(0);
        while (h < t) {
          int u = qu[h++]; List *e = edge_list(g->a[u]);
          for (int i = 0; i < e->n; i++) {
            V ev = e->a[i]; i64 w = ev.t == T_LIST ? toint(LST(ev)->a[0], "간선") : toint(ev, "간선");
            if (w < 0 || w >= N) rt_error("간선이 그래프 밖을 가리켜요");
            if (LST(out)->a[w].u.i < 0) { LST(out)->a[w] = vi(LST(out)->a[u].u.i + 1); qu[t++] = (int)w; }
          }
        }
      } else {
        unsigned char *seen = rt_alloc(N); int *st = rt_alloc(sizeof(int) * (N + 1)), *it = rt_alloc(sizeof(int) * (N + 1)), sp = 0;
        st[sp] = (int)s; it[sp] = 0; sp++; seen[s] = 1; lpush(LST(out), vi(s));
        while (sp) {
          int u = st[sp - 1]; List *e = edge_list(g->a[u]);
          if (it[sp - 1] >= e->n) { sp--; continue; }
          V ev = e->a[it[sp - 1]++]; i64 w = ev.t == T_LIST ? toint(LST(ev)->a[0], "간선") : toint(ev, "간선");
          if (w < 0 || w >= N) rt_error("간선이 그래프 밖을 가리켜요");
          if (!seen[w]) { seen[w] = 1; lpush(LST(out), vi(w)); st[sp] = (int)w; it[sp] = 0; sp++; }
        }
      }
      return out;
    }
    case BI_Dj: {
      need(n, 2, 2, id); List *g = edge_list(a[0]); int N = g->n; i64 s = toint(a[1], "시작점은 정수예요");
      if (s < 0 || s >= N) rt_error("시작점이 그래프 밖에 있어요");
      i64 *d = rt_alloc(sizeof(i64) * N); for (int i = 0; i < N; i++) d[i] = -1;
      /* binary heap of (dist, node) */
      int hc = 16, hn = 0; i64 *hd = rt_alloc(sizeof(i64) * hc); int *hv = rt_alloc(sizeof(int) * hc);
      #define HPUSH(D, X) do { if (hn == hc) { hd = rt_grow(hd, sizeof(i64) * hc, sizeof(i64) * hc * 2); hv = rt_grow(hv, sizeof(int) * hc, sizeof(int) * hc * 2); hc *= 2; } \
        int _i = hn++; hd[_i] = (D); hv[_i] = (X); while (_i > 0) { int _p = (_i - 1) / 2; if (hd[_p] <= hd[_i]) break; i64 _t = hd[_p]; hd[_p] = hd[_i]; hd[_i] = _t; int _u = hv[_p]; hv[_p] = hv[_i]; hv[_i] = _u; _i = _p; } } while (0)
      d[s] = 0; HPUSH(0, (int)s);
      while (hn) {
        i64 du = hd[0]; int u = hv[0]; hn--; hd[0] = hd[hn]; hv[0] = hv[hn];
        for (int i = 0;;) { int l = 2 * i + 1, r = l + 1, m = i; if (l < hn && hd[l] < hd[m]) m = l; if (r < hn && hd[r] < hd[m]) m = r; if (m == i) break; i64 t = hd[m]; hd[m] = hd[i]; hd[i] = t; int t2 = hv[m]; hv[m] = hv[i]; hv[i] = t2; i = m; }
        if (du != d[u]) continue;
        List *e = edge_list(g->a[u]);
        for (int i = 0; i < e->n; i++) {
          List *ed = as_list(e->a[i], "Dj 의 간선은 [도착, 가중치] 예요");
          if (ed->n < 2) rt_error("Dj 의 간선은 [도착, 가중치] 예요");
          i64 v = toint(ed->a[0], "간선"), w = toint(ed->a[1], "가중치");
          if (v < 0 || v >= N) rt_error("간선이 그래프 밖을 가리켜요");
          if (w < 0) rt_error("Dj 는 음수 가중치를 못 다뤄요");
          if (d[v] < 0 || du + w < d[v]) { d[v] = du + w; HPUSH(d[v], (int)v); }
        }
      }
      #undef HPUSH
      V out = vlist(N); for (int i = 0; i < N; i++) lpush(LST(out), vi(d[i]));
      return out;
    }
    case BI_Fw: {
      need(n, 1, 1, id); List *m = as_list(a[0], "Fw 는 거리 행렬이에요"); int N = m->n;
      i64 *d = rt_alloc(sizeof(i64) * N * N);
      for (int i = 0; i < N; i++) {
        List *row = as_list(m->a[i], "Fw 는 거리 행렬이에요");
        if (row->n != N) rt_error("Fw 의 행렬은 정사각형이어야 해요");
        for (int j = 0; j < N; j++) d[i * N + j] = i == j ? 0 : toint(row->a[j], "거리는 정수예요");
      }
      for (int k = 0; k < N; k++) for (int i = 0; i < N; i++) { if (d[i * N + k] < 0) continue;
        for (int j = 0; j < N; j++) { if (d[k * N + j] < 0) continue; i64 c = d[i * N + k] + d[k * N + j]; if (d[i * N + j] < 0 || c < d[i * N + j]) d[i * N + j] = c; } }
      V out = vlist(N);
      for (int i = 0; i < N; i++) { V row = vlist(N); for (int j = 0; j < N; j++) lpush(LST(row), vi(d[i * N + j])); lpush(LST(out), row); }
      return out;
    }
    case BI_Tp: {
      need(n, 1, 1, id); List *g = edge_list(a[0]); int N = g->n;
      int *indeg = rt_alloc(sizeof(int) * (N + 1)), *qu = rt_alloc(sizeof(int) * (N + 1)), h = 0, t = 0;
      for (int u = 0; u < N; u++) { List *e = edge_list(g->a[u]); for (int i = 0; i < e->n; i++) { V ev = e->a[i]; i64 w = ev.t == T_LIST ? toint(LST(ev)->a[0], "간선") : toint(ev, "간선"); if (w < 0 || w >= N) rt_error("간선이 그래프 밖을 가리켜요"); indeg[w]++; } }
      for (int u = 0; u < N; u++) if (!indeg[u]) qu[t++] = u;
      V out = vlist(N);
      while (h < t) {
        int u = qu[h++]; lpush(LST(out), vi(u)); List *e = edge_list(g->a[u]);
        for (int i = 0; i < e->n; i++) { V ev = e->a[i]; i64 w = ev.t == T_LIST ? LST(ev)->a[0].u.i : ev.u.i; if (!--indeg[w]) qu[t++] = (int)w; }
      }
      if (LST(out)->n != N) LST(out)->n = 0;
      return out;
    }
    case BI_Uf: { need(n, 1, 1, id); i64 k = toint(a[0], "Uf 는 정수"); V r = vlist((int)k); for (i64 i = 0; i < k; i++) lpush(LST(r), vi(i)); return r; }
    case BI_Fd: {
      need(n, 2, 2, id); List *p = as_list(a[0], "Fd(부모 리스트, x)"); i64 x = toint(a[1], "Fd 는 정수");
      i64 r = x; while (p->a[norm_index(r, p->n)].u.i != r) r = p->a[r].u.i;
      while (p->a[x].u.i != r) { i64 nx = p->a[x].u.i; p->a[x] = vi(r); x = nx; }
      return vi(r);
    }
    case BI_Un: {
      need(n, 3, 3, id);
      V ra = rt_bi(BI_Fd, (V[]){ a[0], a[1] }, 2), rb = rt_bi(BI_Fd, (V[]){ a[0], a[2] }, 2);
      if (ra.u.i == rb.u.i) return vi(0);
      LST(a[0])->a[rb.u.i] = ra; return vi(1);
    }
    case BI_Kr: {
      need(n, 2, 2, id); i64 N = toint(a[0], "Kr(정점 수, 간선들)");
      V es = copy_deep(a[1]); rt_sort(es, 0, vi(0)); V par = rt_bi(BI_Uf, (V[]){ vi(N) }, 1);
      i64 total = 0, used = 0; List *l = LST(es);
      for (int i = 0; i < l->n; i++) {
        List *e = as_list(l->a[i], "Kr 의 간선은 [가중치, u, v] 예요");
        if (e->n < 3) rt_error("Kr 의 간선은 [가중치, u, v] 예요");
        if (rt_bi(BI_Un, (V[]){ par, e->a[1], e->a[2] }, 3).u.i) { total += toint(e->a[0], "가중치"); used++; }
      }
      return vi(used == N - 1 || N <= 1 ? total : -1);
    }
    case BI_Q: { need(n, 0, 0, id); return vobj(T_DEQ, mkdeq()); }
    case BI_PQ: {
      need(n, 0, 1, id); Pq *q = rt_alloc(sizeof(Pq)); q->h = mklist(8);
      if (n == 1) {
        if (a[0].t != T_FN) rt_type_error("PQ 에는 순서를 정할 함수를 넘겨요", a[0]);
        Fn *f = a[0].u.p;
        if (f->bi == BI_m) q->mode = 1; else if (f->bi == BI_M) q->mode = 0; else { q->mode = 2; q->cmp = a[0]; }
      }
      return vobj(T_PQ, q);
    }
    case BI_ST: case BI_MP: {
      need(n, 0, 1, id); Tree *t = rt_alloc(sizeof(Tree)); V r = vobj(id == BI_ST ? T_SET : T_MAP, t);
      if (n == 1) { List *l = as_list(a[0], "처음 값들은 리스트로 넘겨요"); for (int i = 0; i < l->n; i++) { if (id == BI_ST) tr_insert(t, l->a[i], vi(0)); else { List *p = as_list(l->a[i], "맵의 처음 값은 [키, 값] 리스트예요"); tr_insert(t, p->a[0], p->n > 1 ? p->a[1] : vi(0))->v = p->n > 1 ? p->a[1] : vi(0); } } }
      return r;
    }
    case BI_Rl: need(n, 0, 0, id); return rt_readline();
    case BI_SORT: case BI_SORTD: {
      need(n, 1, 2, id);
      if (n == 2) return rt_sort(a[0], 2, a[1]);
      return rt_sort(a[0], id == BI_SORTD, vi(0));
    }
    case BI_SZ: need(n, 1, 1, id); return vi(rt_size(a[0]));
    case BI_SUB: {
      need(n, 2, 3, id); if (a[0].t != T_STR) rt_type_error("s'' 는 문자열에 써요", a[0]);
      Str *s = STR(a[0]); i64 st = toint(a[1], "시작 위치는 정수예요"); if (st < 0) st += s->n;
      i64 len = n == 3 ? toint(a[2], "길이는 정수예요") : s->n - st;
      if (st < 0) st = 0; if (st > s->n) st = s->n; if (len < 0) len = 0; if (st + len > s->n) len = s->n - st;
      return vstr(s->s + st, (int)len);
    }
    case BI_FIND: {
      need(n, 2, 2, id); if (a[0].t != T_STR) rt_type_error("s''' 는 문자열에 써요", a[0]);
      V t = rt_tostr(a[1]); Str *s = STR(a[0]), *p = STR(t);
      for (int i = 0; i + p->n <= s->n; i++) if (!memcmp(s->s + i, p->s, p->n)) return vi(i);
      return vi(-1);
    }
    case BI_REPL: {
      need(n, 3, 3, id); if (a[0].t != T_STR) rt_type_error("s'''' 는 문자열에 써요", a[0]);
      V f = rt_tostr(a[1]), t = rt_tostr(a[2]); Str *s = STR(a[0]), *p = STR(f), *q = STR(t);
      if (!p->n) return a[0];
      V r = vstr("", 0);
      size_t save = out_len; (void)save;
      Str *o = STR(r); int cap = s->n + 16; o->s = rt_alloc(cap); o->cap = cap;
      for (int i = 0; i < s->n;) {
        int hit = i + p->n <= s->n && !memcmp(s->s + i, p->s, p->n);
        const char *src = hit ? q->s : s->s + i; int len = hit ? q->n : 1;
        if (o->n + len + 1 > o->cap) { int nc = (o->n + len + 1) * 2; o->s = rt_grow(o->s, o->cap, nc); o->cap = nc; }
        memcpy(o->s + o->n, src, len); o->n += len; i += hit ? p->n : 1;
      }
      return r;
    }
  }
  rt_error("알 수 없는 내장 함수예요");
}
/* ======================= end of umm runtime ======================= */
