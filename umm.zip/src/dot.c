/* ===================================================================
 * umm: lexer, parser, name resolver, interpreter and C code generator.
 * Build natively with -DDOT_CLI for the command line tool, or for
 * wasm32 for the browser IDE.
 * =================================================================== */
#ifdef DOT_CLI
#define RT_NATIVE 1
#endif
#include "rt.c"
#include "rt_src.h"   /* RT_SRC: the runtime source, embedded into generated C */

/* ------------------------------------------------------------------ */
/* small utilities                                                     */
/* ------------------------------------------------------------------ */
static RT_NORETURN void fe_error(int line, const char *msg) {
  char buf[600]; int n = 0; const char *s = "문법 오류";
  while (*s) buf[n++] = *s++;
  if (line > 0) { s = " (줄 "; while (*s) buf[n++] = *s++; n += rt_fmt_int(buf + n, line); buf[n++] = ')'; }
  buf[n++] = ':'; buf[n++] = ' ';
  while (*msg && n < 590) buf[n++] = *msg++;
  buf[n] = 0;
#ifdef RT_NATIVE
  fprintf(stderr, "%s\n", buf); exit(2);
#else
  js_error(buf, n); __builtin_trap();
#endif
}
static int streq(const char *a, int an, const char *b) { int bn = (int)strlen(b); return an == bn && !memcmp(a, b, an); }
static char *sdup(const char *s, int n) { char *r = rt_alloc(n + 1); memcpy(r, s, n); r[n] = 0; return r; }
static int strcmp_same(const char *a, const char *b) { while (*a && *a == *b) { a++; b++; } return *a != *b; }

/* growable text buffer */
typedef struct { char *s; int n, cap; } Buf;
static void bput(Buf *b, const char *s, int n) {
  if (b->n + n + 1 > b->cap) { int nc = b->cap ? b->cap * 2 : 4096; while (nc < b->n + n + 1) nc *= 2; b->s = rt_grow(b->s, b->cap, nc); b->cap = nc; }
  memcpy(b->s + b->n, s, n); b->n += n; b->s[b->n] = 0;
}
static void bs(Buf *b, const char *s) { bput(b, s, (int)strlen(s)); }
static void bi(Buf *b, i64 x) { char t[24]; int n = rt_fmt_int(t, x); bput(b, t, n); }

/* ------------------------------------------------------------------ */
/* lexer                                                               */
/* ------------------------------------------------------------------ */
enum {
  K_EOF, K_NL, K_INDENT, K_DEDENT, K_ID, K_INT, K_DBL, K_STR, K_PREC,
  K_LP, K_RP, K_LB, K_RB, K_COMMA, K_SEMI, K_COLON, K_QMARK,
  K_D1, K_D2, K_D3, K_D4, K_P3,
  K_PLUS, K_MINUS, K_STAR, K_SLASH, K_PCT, K_INC, K_DEC,
  K_ASSIGN, K_ADDEQ, K_SUBEQ, K_MULEQ, K_DIVEQ, K_MODEQ,
  K_EQ, K_NE, K_LT, K_GT, K_LE, K_GE, K_AND, K_OR, K_NOT,
  K_BAND, K_BOR, K_BXOR, K_BNOT, K_SHL, K_SHR, K_QUOTE, K_SFN
};
typedef struct { int k, line; i64 iv; double dv; char *s; int n; int x; } Tok;
static Tok *toks; static int ntok, captok;

static void emit(int k, int line) {
  if (ntok == captok) { int nc = captok ? captok * 2 : 1024; toks = rt_grow(toks, sizeof(Tok) * captok, sizeof(Tok) * nc); captok = nc; }
  Tok *t = &toks[ntok++]; memset(t, 0, sizeof(Tok)); t->k = k; t->line = line;
}
static int continues_line(int k) {
  switch (k) {
    case K_COMMA: case K_LP: case K_LB: case K_PLUS: case K_STAR: case K_SLASH: case K_PCT:
    case K_AND: case K_OR: case K_BAND: case K_BOR: case K_BXOR: case K_SHL: case K_SHR:
    case K_EQ: case K_NE: case K_LT: case K_GT: case K_LE: case K_GE:
    case K_ASSIGN: case K_ADDEQ: case K_SUBEQ: case K_MULEQ: case K_DIVEQ: case K_MODEQ: case K_QMARK:
      return 1;
  }
  return 0;
}
static int isal(int c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; }
static int isdg(int c) { return c >= '0' && c <= '9'; }

static void lex(const char *src, int len) {
  ntok = 0;
  int pos = 0, line = 1, at_start = 1, cont = 0;
  int ind[256], nind = 1; ind[0] = 0;
  while (1) {
    if (at_start) {
      int col = 0, p = pos;
      while (p < len && (src[p] == ' ' || src[p] == '\t' || src[p] == '\r')) { col += src[p] == '\t' ? 4 - col % 4 : (src[p] == ' '); p++; }
      if (p >= len) { pos = p; break; }
      if (src[p] == '\n' || (src[p] == '/' && p + 1 < len && src[p + 1] == '/')) {
        while (p < len && src[p] != '\n') p++;
        if (p < len) p++;
        pos = p; line++; continue;   /* blank or comment-only line */
      }
      pos = p; at_start = 0;
      if (!cont) {
        if (col > ind[nind - 1]) { if (nind == 255) fe_error(line, "들여쓰기가 너무 깊어요"); ind[nind++] = col; emit(K_INDENT, line); }
        else {
          while (col < ind[nind - 1]) { nind--; emit(K_DEDENT, line); }
          if (col != ind[nind - 1]) fe_error(line, "들여쓰기 칸 수가 위쪽 줄과 맞지 않아요");
        }
      }
      cont = 0;
    }
    if (pos >= len) break;
    int c = (unsigned char)src[pos];
    if (c == '\n') {
      pos++; at_start = 1;
      if (ntok && continues_line(toks[ntok - 1].k)) cont = 1;
      else if (ntok && toks[ntok - 1].k != K_NL && toks[ntok - 1].k != K_INDENT && toks[ntok - 1].k != K_DEDENT) emit(K_NL, line);
      line++; continue;
    }
    if (c == ' ' || c == '\t' || c == '\r') { pos++; continue; }
    if (c == '/' && pos + 1 < len && src[pos + 1] == '/') { while (pos < len && src[pos] != '\n') pos++; continue; }
    int prevk = ntok ? toks[ntok - 1].k : -1;
    if (isal(c)) {
      int st = pos; while (pos < len && isal((unsigned char)src[pos])) pos++;
      if (pos - st == 1 && src[st] == 's' && pos < len && src[pos] == '\'') {
        int q = 0; while (pos < len && src[pos] == '\'') { q++; pos++; }
        if (q > 4) fe_error(line, "s 뒤의 따옴표는 4개까지예요");
        emit(K_SFN, line); toks[ntok - 1].x = q; continue;
      }
      emit(K_ID, line); toks[ntok - 1].s = sdup(src + st, pos - st); toks[ntok - 1].n = pos - st;
      if (pos < len && isdg((unsigned char)src[pos])) goto prec;
      continue;
    }
    if (isdg(c)) {
      if (prevk == K_RP || prevk == K_RB) {
      prec: {
          int p = 0; while (pos < len && isdg((unsigned char)src[pos])) p = p * 10 + (src[pos++] - '0');
          if (p > 15) fe_error(line, "소수점 자리는 15자리까지예요");
          emit(K_PREC, line); toks[ntok - 1].x = p; continue;
        }
      }
      int st = pos, isd = 0;
      while (pos < len && isdg((unsigned char)src[pos])) pos++;
      if (pos + 1 < len && src[pos] == '.' && isdg((unsigned char)src[pos + 1])) { isd = 1; pos++; while (pos < len && isdg((unsigned char)src[pos])) pos++; }
      if (pos < len && (src[pos] == 'e' || src[pos] == 'E') && pos + 1 < len && (isdg((unsigned char)src[pos + 1]) || ((src[pos + 1] == '-' || src[pos + 1] == '+') && pos + 2 < len && isdg((unsigned char)src[pos + 2])))) {
        isd = 1; pos += 2; while (pos < len && isdg((unsigned char)src[pos])) pos++;
      }
      i64 iv; double dv; int k = rt_parse_num(src + st, pos - st, &iv, &dv);
      if (k == 1 && !isd) { emit(K_INT, line); toks[ntok - 1].iv = iv; }
      else { emit(K_DBL, line); toks[ntok - 1].dv = k == 1 ? (double)iv : dv; toks[ntok - 1].s = sdup(src + st, pos - st); toks[ntok - 1].n = pos - st; }
      if (pos < len && isal((unsigned char)src[pos])) fe_error(line, "숫자 바로 뒤에 글자가 붙어 있어요");
      continue;
    }
    if (c == '"') {
      pos++; Buf b = { 0 };
      while (pos < len && src[pos] != '"') {
        if (src[pos] == '\n') fe_error(line, "문자열이 닫히지 않았어요");
        if (src[pos] == '\\' && pos + 1 < len) {
          char e = src[pos + 1], o = e;
          if (e == 'n') o = '\n'; else if (e == 't') o = '\t'; else if (e == '0') o = 0;
          bput(&b, &o, 1); pos += 2; continue;
        }
        bput(&b, src + pos, 1); pos++;
      }
      if (pos >= len) fe_error(line, "문자열이 닫히지 않았어요");
      pos++;
      emit(K_STR, line); toks[ntok - 1].s = b.s ? b.s : sdup("", 0); toks[ntok - 1].n = b.n;
      continue;
    }
    if (c == '.') {
      int q = 0; while (pos < len && src[pos] == '.') { q++; pos++; }
      if (q > 4) fe_error(line, "점은 4개(....)까지만 써요");
      emit(K_D1 + q - 1, line); continue;
    }
    if (c == '\'') {
      int q = 0; while (pos < len && src[pos] == '\'') { q++; pos++; }
      if (q > 2) fe_error(line, "정렬 기호는 ' 또는 '' 예요");
      emit(K_QUOTE, line); toks[ntok - 1].x = q; continue;
    }
#define TWO(a, b, k2, k1) if (c == a) { if (pos + 1 < len && src[pos + 1] == b) { pos += 2; emit(k2, line); } else { pos++; emit(k1, line); } continue; }
    if (c == '+') {
      if (pos + 2 < len && src[pos + 1] == '+' && src[pos + 2] == '+') { pos += 3; emit(K_P3, line); continue; }
      if (pos + 1 < len && src[pos + 1] == '+') { pos += 2; emit(K_INC, line); continue; }
      TWO('+', '=', K_ADDEQ, K_PLUS)
    }
    if (c == '-') {
      if (pos + 1 < len && src[pos + 1] == '-') { pos += 2; emit(K_DEC, line); continue; }
      TWO('-', '=', K_SUBEQ, K_MINUS)
    }
    TWO('*', '=', K_MULEQ, K_STAR)
    TWO('/', '=', K_DIVEQ, K_SLASH)
    TWO('%', '=', K_MODEQ, K_PCT)
    TWO('=', '=', K_EQ, K_ASSIGN)
    TWO('!', '=', K_NE, K_NOT)
    if (c == '<') { if (pos + 1 < len && src[pos + 1] == '<') { pos += 2; emit(K_SHL, line); continue; } TWO('<', '=', K_LE, K_LT) }
    if (c == '>') { if (pos + 1 < len && src[pos + 1] == '>') { pos += 2; emit(K_SHR, line); continue; } TWO('>', '=', K_GE, K_GT) }
    TWO('&', '&', K_AND, K_BAND)
    TWO('|', '|', K_OR, K_BOR)
#undef TWO
    pos++;
    switch (c) {
      case '(': emit(K_LP, line); break;
      case ')': emit(K_RP, line); break;
      case '[': emit(K_LB, line); break;
      case ']': emit(K_RB, line); break;
      case ',': emit(K_COMMA, line); break;
      case ';': emit(K_SEMI, line); break;
      case ':': emit(K_COLON, line); break;
      case '?': emit(K_QMARK, line); break;
      case '^': emit(K_BXOR, line); break;
      case '~': emit(K_BNOT, line); break;
      default: {
        char m[64] = "알 수 없는 글자예요: ";
        int k = (int)strlen(m); m[k++] = (char)c; m[k] = 0;
        fe_error(line, m);
      }
    }
  }
  if (ntok && toks[ntok - 1].k != K_NL && toks[ntok - 1].k != K_DEDENT && toks[ntok - 1].k != K_INDENT) emit(K_NL, line);
  while (nind > 1) { nind--; emit(K_DEDENT, line); }
  emit(K_EOF, line);
}

/* ------------------------------------------------------------------ */
/* AST                                                                 */
/* ------------------------------------------------------------------ */
enum {
  N_INT, N_DBL, N_STR, N_NIL, N_VAR, N_BIN, N_UN, N_AND, N_OR, N_TERN, N_INDEX,
  N_CALLN,   /* call by name, resolved into one of the next three */
  N_CALL, N_BICALL, N_CALLV, N_FNREF, N_BIREF, N_LAMBDA, N_LIST, N_PREC,
  S_EXPR, S_ASSIGN, S_OPASSIGN, S_INC, S_DECL, S_READ, S_PRINT, S_IF, S_SWITCH,
  S_FORC, S_FORR, S_WHILE, S_DO, S_FOREACH, S_BREAK, S_CONT, S_RET, S_BLOCK, S_CONST, S_NOP, S_CASE
};
typedef struct Node {
  int k, line;
  struct Node *a, *b, *c, *d;
  struct Node **v; int n;          /* children list */
  i64 i; double dv; char *s; int sn;
  int x, y;                        /* op / slot / scope / misc */
} Node;
typedef struct Func {
  char *name; int line;
  int np; char **pn; int *isref; Node **defs;
  Node *body; int nloc; char **loc; int locap;
  int is_lambda, id;
} Func;
static Func **funcs; static int nfunc, capfunc;
static char **gnames; static int ng, capg;
static int *gconst;

static Node *mk(int k, int line) { Node *n = rt_alloc(sizeof(Node)); n->k = k; n->line = line; return n; }
static void push_node(Node *p, Node *c) {
  if ((p->n & (p->n - 1)) == 0) { int nc = p->n ? p->n * 2 : 1; p->v = rt_grow(p->v, sizeof(Node *) * p->n, sizeof(Node *) * nc); }
  p->v[p->n++] = c;
}
static Func *new_func(void) {
  Func *f = rt_alloc(sizeof(Func));
  if (nfunc == capfunc) { int nc = capfunc ? capfunc * 2 : 16; funcs = rt_grow(funcs, sizeof(Func *) * capfunc, sizeof(Func *) * nc); capfunc = nc; }
  f->id = nfunc; funcs[nfunc++] = f; return f;
}

/* ------------------------------------------------------------------ */
/* parser                                                              */
/* ------------------------------------------------------------------ */
static int P;
static Tok *T(int o) { int i = P + o; return &toks[i < ntok ? i : ntok - 1]; }
static int K(int o) { return T(o)->k; }
static int LN(void) { return T(0)->line; }
static void expect(int k, const char *msg) { if (K(0) != k) fe_error(LN(), msg); P++; }
static int at_stmt_end(int o) { int k = K(o); return k == K_NL || k == K_SEMI || k == K_EOF || k == K_DEDENT; }
/* index of the token matching the paren/bracket at position P+o on the same line; -1 if none */
static int match_close(int o) {
  int d = 0;
  for (int i = P + o; i < ntok; i++) {
    int k = toks[i].k;
    if (k == K_NL || k == K_EOF || k == K_INDENT || k == K_DEDENT) return -1;
    if (k == K_LP || k == K_LB) d++;
    else if (k == K_RP || k == K_RB) { if (--d == 0) return i - P; }
  }
  return -1;
}

static Node *parse_expr(void);
static Node *parse_tern(int allow_colon);
static Node *parse_block(void);
static Node *parse_body(void);
static Node *parse_stmt(void);
static Node *parse_simple(void);

static Node *parse_args(Node *call) {   /* at '(' */
  expect(K_LP, "( 가 필요해요");
  if (K(0) != K_RP) { for (;;) { push_node(call, parse_expr()); if (K(0) != K_COMMA) break; P++; } }
  expect(K_RP, ") 가 필요해요");
  return call;
}
static int starts_expr(int k) {
  return k == K_ID || k == K_INT || k == K_DBL || k == K_STR || k == K_NOT || k == K_BNOT || k == K_QUOTE || k == K_SFN;
}
static Node *parse_lambda(void) {   /* at '-' '(' */
  int line = LN(); P += 2;
  Func *f = new_func(); f->is_lambda = 1; f->line = line; f->name = "lambda";
  if (K(0) != K_RP) {
    for (;;) {
      if (K(0) != K_ID) fe_error(line, "람다의 매개변수는 이름이어야 해요");
      f->pn = rt_grow(f->pn, sizeof(char *) * f->np, sizeof(char *) * (f->np + 1));
      f->isref = rt_grow(f->isref, sizeof(int) * f->np, sizeof(int) * (f->np + 1));
      f->defs = rt_grow(f->defs, sizeof(Node *) * f->np, sizeof(Node *) * (f->np + 1));
      f->pn[f->np++] = T(0)->s; P++;
      if (K(0) != K_COMMA) break; P++;
    }
  }
  expect(K_RP, ") 가 필요해요");
  Node *ret = mk(S_RET, line); ret->a = parse_tern(1);
  Node *blk = mk(S_BLOCK, line); push_node(blk, ret); f->body = blk;
  Node *n = mk(N_LAMBDA, line); n->x = f->id; return n;
}
static int looks_like_lambda(void) {   /* at '-' '(' in expression position */
  int m = match_close(1); if (m < 0) return 0;
  for (int i = 2; i < m; i++) { int k = K(i); if ((i % 2 == 0 && k != K_ID) || (i % 2 == 1 && k != K_COMMA)) return 0; }
  int after = K(m + 1);
  return starts_expr(after);
}
static Node *parse_primary(void) {
  Tok *t = T(0); int line = t->line; Node *n;
  switch (t->k) {
    case K_INT: P++; n = mk(N_INT, line); n->i = t->iv; return n;
    case K_DBL: P++; n = mk(N_DBL, line); n->dv = t->dv; n->s = t->s; n->sn = t->n; return n;
    case K_STR: P++; n = mk(N_STR, line); n->s = t->s; n->sn = t->n; return n;
    case K_ID:
      P++;
      if (streq(t->s, t->n, "nil")) return mk(N_NIL, line);
      if (K(0) == K_LP) { n = mk(N_CALLN, line); n->s = t->s; n->sn = t->n; return parse_args(n); }
      n = mk(N_VAR, line); n->s = t->s; n->sn = t->n; return n;
    case K_LP: { P++; n = parse_expr(); expect(K_RP, ") 가 필요해요"); return n; }
    case K_LB: {
      P++; n = mk(N_LIST, line);
      if (K(0) != K_RB) { for (;;) { push_node(n, parse_expr()); if (K(0) != K_COMMA) break; P++; if (K(0) == K_RB) break; } }
      expect(K_RB, "] 가 필요해요"); return n;
    }
    case K_QUOTE: {
      P++; n = mk(N_BICALL, line); n->x = t->x == 1 ? BI_SORT : BI_SORTD;
      if (K(0) != K_LP) fe_error(line, "정렬은 '(리스트) 처럼 써요");
      return parse_args(n);
    }
    case K_SFN: {
      P++; n = mk(N_BICALL, line); n->x = BI_SZ + t->x - 1;
      if (K(0) != K_LP) fe_error(line, "s' 함수는 s'(값) 처럼 써요");
      return parse_args(n);
    }
    case K_MINUS:
      if (K(1) == K_LP && looks_like_lambda()) return parse_lambda();
      /* fallthrough */
    default:
      fe_error(line, "여기에는 값이 와야 해요");
  }
}
static Node *parse_postfix(void) {
  Node *n = parse_primary();
  for (;;) {
    if (K(0) == K_LB) { int line = LN(); P++; Node *x = mk(N_INDEX, line); x->a = n; x->b = parse_expr(); expect(K_RB, "] 가 필요해요"); n = x; }
    else if (K(0) == K_PREC) { Node *x = mk(N_PREC, LN()); x->a = n; x->x = T(0)->x; P++; n = x; }
    else if (K(0) == K_LP && (n->k == N_INDEX || n->k == N_CALLN)) {
      Node *x = mk(N_CALLV, LN()); x->a = n; parse_args(x); n = x;
    } else break;
  }
  return n;
}
static Node *parse_unary(void) {
  int k = K(0), line = LN();
  if (k == K_MINUS) {
    if (K(1) == K_LP && looks_like_lambda()) return parse_lambda();
    P++; Node *n = mk(N_UN, line); n->x = K_MINUS; n->a = parse_unary(); return n;
  }
  if (k == K_NOT || k == K_BNOT) { P++; Node *n = mk(N_UN, line); n->x = k; n->a = parse_unary(); return n; }
  if (k == K_PLUS) { P++; return parse_unary(); }
  return parse_postfix();
}
static int prec_of(int k) {
  switch (k) {
    case K_OR: return 1; case K_AND: return 2; case K_BOR: return 3; case K_BXOR: return 4; case K_BAND: return 5;
    case K_EQ: case K_NE: return 6; case K_LT: case K_GT: case K_LE: case K_GE: return 7;
    case K_SHL: case K_SHR: return 8; case K_PLUS: case K_MINUS: return 9;
    case K_STAR: case K_SLASH: case K_PCT: return 10;
  }
  return 0;
}
static Node *parse_bin(int minp) {
  Node *l = parse_unary();
  for (;;) {
    int k = K(0), p = prec_of(k);
    if (!p || p < minp) break;
    int line = LN(); P++;
    Node *r = parse_bin(p + 1);
    Node *n = mk(k == K_AND ? N_AND : k == K_OR ? N_OR : N_BIN, line); n->x = k; n->a = l; n->b = r; l = n;
  }
  return l;
}
static Node *parse_tern(int allow_colon) {
  Node *c = parse_bin(1);
  if (K(0) == K_QMARK && allow_colon) {
    int line = LN(); P++;
    Node *n = mk(N_TERN, line); n->a = c; n->b = parse_tern(1);
    expect(K_COLON, "삼항 연산자에 : 가 필요해요"); n->c = parse_tern(1); return n;
  }
  return c;
}
static Node *parse_expr(void) { return parse_tern(1); }

/* --- statements --- */
static Node *as_target(Node *e, int line) {   /* VAR or VAR[d1][d2]... -> target with dims */
  Node *t = mk(S_NOP, line); Node *dims[8]; int nd = 0;
  while (e->k == N_INDEX) { if (nd == 8) fe_error(line, "차원이 너무 많아요"); dims[nd++] = e->b; e = e->a; }
  if (e->k == N_PREC && e->a->k == N_VAR) fe_error(line, "변수 이름에는 숫자를 쓸 수 없어요 (이름 뒤 숫자는 소수점 자리 맞추기예요)");
  if (e->k != N_VAR) fe_error(line, "정의(.)·입력(..)은 이름이나 이름[크기] 에만 쓸 수 있어요");
  t->a = e; for (int i = nd - 1; i >= 0; i--) push_node(t, dims[i]);
  return t;
}
static int is_lvalue(Node *e) {
  if (e->k == N_PREC && e->a->k == N_VAR) fe_error(e->line, "변수 이름에는 숫자를 쓸 수 없어요 (이름 뒤 숫자는 소수점 자리 맞추기예요)");
  return e->k == N_VAR || e->k == N_INDEX;
}
static Node *parse_simple(void) {
  int line = LN();
  if (K(0) == K_P3) { P++; return mk(S_NOP, line); }
  if (K(0) == K_DEC && at_stmt_end(1)) { P++; return mk(S_BREAK, line); }
  if (K(0) == K_MINUS && at_stmt_end(1)) { P++; return mk(S_CONT, line); }
  if (K(0) == K_D4) { P++; Node *r = mk(S_RET, line); if (!at_stmt_end(0)) r->a = parse_expr(); return r; }
  Node *first = parse_expr();
  Node *lhs = mk(S_NOP, line); push_node(lhs, first);
  while (K(0) == K_COMMA) { P++; push_node(lhs, parse_expr()); }
  int k = K(0);
  if (k == K_D1 || k == K_D2) {
    P++; Node *s = mk(k == K_D1 ? S_DECL : S_READ, line);
    for (int i = 0; i < lhs->n; i++) push_node(s, as_target(lhs->v[i], line));
    return s;
  }
  if (k == K_D3) { P++; Node *s = mk(S_PRINT, line); s->v = lhs->v; s->n = lhs->n; return s; }
  if (k == K_ASSIGN) {
    P++; Node *s = mk(S_ASSIGN, line); s->a = lhs;
    Node *rhs = mk(S_NOP, line); push_node(rhs, parse_expr());
    while (K(0) == K_COMMA) { P++; push_node(rhs, parse_expr()); }
    if (rhs->n != lhs->n) fe_error(line, "= 왼쪽과 오른쪽의 개수가 달라요");
    for (int i = 0; i < lhs->n; i++) if (!is_lvalue(lhs->v[i])) fe_error(line, "= 왼쪽에는 이름이나 이름[위치] 가 와야 해요");
    s->b = rhs; return s;
  }
  if (lhs->n > 1) fe_error(line, "쉼표로 묶은 값 뒤에는 . .. ... = 중 하나가 와야 해요");
  if (k >= K_ADDEQ && k <= K_MODEQ) {
    P++; if (!is_lvalue(first)) fe_error(line, "왼쪽에는 이름이나 이름[위치] 가 와야 해요");
    Node *s = mk(S_OPASSIGN, line); s->x = k; s->a = first; s->b = parse_expr(); return s;
  }
  if (k == K_INC || k == K_DEC) {
    P++; if (!is_lvalue(first)) fe_error(line, "++ 와 -- 는 이름이나 이름[위치] 에 붙여요");
    Node *s = mk(S_INC, line); s->x = k == K_INC ? 1 : -1; s->a = first; return s;
  }
  if (first->k == N_VAR) fe_error(line, "이름만 덩그러니 있어요. 정의하려면 끝에 . 출력하려면 ... 을 붙여요");
  Node *s = mk(S_EXPR, line); s->a = first; return s;
}
static Node *parse_inline(void) {   /* statements after a header on the same line */
  Node *b = mk(S_BLOCK, LN());
  for (;;) {
    push_node(b, parse_stmt());
    if (K(0) == K_SEMI) { P++; if (K(0) == K_NL) break; continue; }
    break;
  }
  if (K(0) == K_NL) P++;
  return b;
}
static void end_stmt(void) {
  if (K(0) == K_NL) { P++; return; }
  int prev = P > 0 ? toks[P - 1].k : K_NL;
  if (prev == K_DEDENT || prev == K_NL || K(0) == K_EOF || K(0) == K_DEDENT) return;
  fe_error(LN(), "한 줄에 문장이 끝나지 않았어요 (줄을 바꾸거나 ; 로 나눠요)");
}
static Node *parse_block(void) {   /* NL INDENT stmts DEDENT */
  int line = LN();
  expect(K_NL, "줄이 바뀌어야 해요");
  if (K(0) != K_INDENT) fe_error(line, "이 줄 아래에 들여쓴 몸통이 필요해요");
  P++;
  Node *b = mk(S_BLOCK, line);
  while (K(0) != K_DEDENT && K(0) != K_EOF) {
    Node *st = parse_stmt();
    if (!(st->k == S_NOP && st->x == -1)) push_node(b, st);
    while (K(0) == K_SEMI) { P++; if (K(0) == K_NL) break; push_node(b, parse_stmt()); }
    end_stmt();
  }
  expect(K_DEDENT, "들여쓰기가 끝나지 않았어요");
  return b;
}
static Node *parse_body(void) { return K(0) == K_NL ? parse_block() : parse_inline(); }

static int header_inline_start(int k) {
  return k == K_NL || k == K_ID || k == K_INT || k == K_DBL || k == K_STR || k == K_D4 || k == K_DEC ||
         k == K_MINUS || k == K_QUOTE || k == K_SFN || k == K_P3 || k == K_D1 || k == K_LB;
}
static int is_else(void) { return K(0) == K_LP && K(1) == K_RP && K(2) == K_RP; }
static int is_elseif(void) { return K(0) == K_LP && K(1) == K_LP && match_close(0) < 0 && match_close(1) > 0; }
static int count_top(int from, int to, int kind) {   /* count tokens of kind at depth 1 inside (from, to) */
  int d = 0, c = 0;
  for (int i = from; i <= to; i++) { int k = K(i); if (k == K_LP || k == K_LB) d++; else if (k == K_RP || k == K_RB) d--; else if (k == kind && d == 1) c++; }
  return c;
}
static Node *parse_if_chain(void) {
  int line = LN(); P++;   /* '(' */
  Node *n = mk(S_IF, line); n->a = parse_expr(); expect(K_RP, ") 가 필요해요");
  n->b = parse_body();
  Node *tail = n;
  for (;;) {
    if (is_else()) { int l = LN(); P += 3; tail->c = parse_body(); (void)l; break; }
    if (is_elseif()) {
      int l = LN(); P += 2;
      Node *e = mk(S_IF, l); e->a = parse_expr(); expect(K_RP, ") 가 필요해요");
      e->b = parse_body(); tail->c = e; tail = e; continue;
    }
    break;
  }
  return n;
}
static Node *parse_switch(void) {
  int line = LN(); P += 2;
  Node *n = mk(S_SWITCH, line); n->a = parse_expr();
  expect(K_RP, ") 가 필요해요"); expect(K_RP, ") 가 필요해요");
  expect(K_NL, "((값)) 다음 줄에 경우들을 써요");
  expect(K_INDENT, "경우들은 들여써요");
  while (K(0) != K_DEDENT && K(0) != K_EOF) {
    Node *c = mk(S_CASE, LN());
    if (K(0) == K_ID && streq(T(0)->s, T(0)->n, "_") && K(1) == K_COLON) { P += 2; c->a = 0; }
    else { c->a = parse_tern(0); expect(K_COLON, "경우 뒤에는 : 가 와요"); }
    c->b = parse_body(); push_node(n, c);
  }
  expect(K_DEDENT, "들여쓰기가 끝나지 않았어요");
  return n;
}
static Node *parse_for(int close) {
  int line = LN();
  if (count_top(0, close, K_SEMI) == 2) {
    P++; Node *n = mk(S_FORC, line);
    n->a = K(0) == K_SEMI ? mk(S_NOP, line) : parse_simple(); expect(K_SEMI, "; 가 필요해요");
    n->b = K(0) == K_SEMI ? 0 : parse_expr(); expect(K_SEMI, "; 가 필요해요");
    n->c = K(0) == K_RP ? mk(S_NOP, line) : parse_simple(); expect(K_RP, ") 가 필요해요");
    expect(K_MINUS, "반복문은 (...)- 처럼 끝에 - 가 붙어요");
    n->d = parse_body(); return n;
  }
  int commas = count_top(0, close, K_COMMA);
  if (commas < 1 || commas > 3) fe_error(line, "반복은 (i; 조건; 증가)- 또는 (i, 끝)- (i, 시작, 끝)- (i, 시작, 끝, 간격)- 이에요");
  P++;
  if (K(0) != K_ID) fe_error(line, "반복 변수 이름이 먼저 와요");
  Node *n = mk(S_FORR, line); n->a = mk(N_VAR, line); n->a->s = T(0)->s; n->a->sn = T(0)->n; P++;
  expect(K_COMMA, ", 가 필요해요");
  Node *e1 = parse_expr(), *e2 = 0, *e3 = 0;
  if (K(0) == K_COMMA) { P++; e2 = parse_expr(); }
  if (K(0) == K_COMMA) { P++; e3 = parse_expr(); }
  expect(K_RP, ") 가 필요해요"); expect(K_MINUS, "반복문은 끝에 - 가 붙어요");
  if (!e2) { n->b = mk(N_INT, line); n->c = e1; } else { n->b = e1; n->c = e2; }
  n->d = e3;   /* step expression, may be null */
  n->x = 0;
  Node *body = parse_body();
  Node *wrap = mk(S_BLOCK, line); push_node(wrap, body);
  n->v = wrap->v; n->n = 1;   /* body stored in v[0] */
  return n;
}
static Node *parse_funcdef(void) {
  int line = LN(); Tok *name = T(0); P += 3;   /* name - ( */
  Func *f = new_func(); f->name = name->s; f->line = line;
  if (K(0) != K_RP) {
    for (;;) {
      int ref = 0;
      if (K(0) != K_ID) fe_error(line, "매개변수는 이름이어야 해요");
      char *nm = T(0)->s; int nn = T(0)->n;
      if (nm[0] == '_' && nn > 1) { ref = 1; nm = nm + 1; }
      P++;
      Node *def = 0;
      if (K(0) == K_ASSIGN) { P++; def = parse_expr(); if (ref) fe_error(line, "참조 매개변수(_)에는 기본값을 줄 수 없어요"); }
      f->pn = rt_grow(f->pn, sizeof(char *) * f->np, sizeof(char *) * (f->np + 1));
      f->isref = rt_grow(f->isref, sizeof(int) * f->np, sizeof(int) * (f->np + 1));
      f->defs = rt_grow(f->defs, sizeof(Node *) * f->np, sizeof(Node *) * (f->np + 1));
      f->pn[f->np] = nm; f->isref[f->np] = ref; f->defs[f->np] = def; f->np++;
      if (K(0) != K_COMMA) break; P++;
    }
  }
  expect(K_RP, ") 가 필요해요");
  for (int i = 1; i < f->np; i++) if (f->defs[i - 1] && !f->defs[i]) fe_error(line, "기본값이 있는 매개변수 뒤에는 기본값 없는 매개변수가 올 수 없어요");
  f->body = parse_body();
  Node *n = mk(S_NOP, line); n->x = -1; return n;
}
static int is_funcdef(void) {
  if (!(K(0) == K_ID && K(1) == K_MINUS && K(2) == K_LP)) return 0;
  int m = match_close(2); if (m < 0) return 0;
  int after = K(m + 1);
  if (after == K_NL) return K(m + 2) == K_INDENT;
  return after == K_D4 || after == K_ID || after == K_DEC || after == K_QUOTE || after == K_SFN;
}
static Node *parse_stmt(void) {
  int k = K(0), line = LN();
  if (k == K_INDENT) fe_error(line, "들여쓰기가 필요 없는 곳이에요");
  if (is_funcdef()) return parse_funcdef();
  if (k == K_D1 && K(1) == K_LP) {
    if (K(2) == K_RP) {   /* do-while: .() body  .(cond) */
      P += 3; Node *n = mk(S_DO, line); n->b = parse_body();
      if (!(K(0) == K_D1 && K(1) == K_LP)) fe_error(line, ".() 몸통 다음 줄에 .(조건) 이 와야 해요");
      P += 2; n->a = parse_expr(); expect(K_RP, ") 가 필요해요");
      if (K(0) == K_NL) P++;
      return n;
    }
    P += 2; Node *n = mk(S_WHILE, line); n->a = parse_expr(); expect(K_RP, ") 가 필요해요");
    n->b = parse_body(); return n;
  }
  if (k == K_D1 && K(1) == K_ID && K(2) == K_ASSIGN) {
    P++; Node *n = mk(S_CONST, line); n->a = mk(N_VAR, line); n->a->s = T(0)->s; n->a->sn = T(0)->n;
    P += 2; n->b = parse_expr(); return n;
  }
  if (k == K_MINUS && K(1) == K_LP && K(2) == K_ID && K(3) == K_COMMA) {
    int m = match_close(1);
    if (m > 0 && header_inline_start(K(m + 1))) {
      P += 2; Node *n = mk(S_FOREACH, line); n->a = mk(N_VAR, line); n->a->s = T(0)->s; n->a->sn = T(0)->n;
      P += 2; n->b = parse_expr(); expect(K_RP, ") 가 필요해요");
      n->c = parse_body(); return n;
    }
  }
  if (k == K_LP) {
    if (is_else()) fe_error(line, "()) 앞에 (조건) 이 없어요");
    if (is_elseif()) fe_error(line, "((조건) 앞에 (조건) 이 없어요");
    int m = match_close(0);
    if (m > 0) {
      int after = K(m + 1);
      if (after == K_MINUS && (count_top(0, m, K_SEMI) == 2 || count_top(0, m, K_COMMA) >= 1)) return parse_for(m);
      if (K(1) == K_LP && match_close(1) == m - 1 && after == K_NL && K(m + 2) == K_INDENT) {
        /* ((x)) followed by case labels -> switch */
        int i = m + 3, lab = 0;
        if (K(i) == K_ID && streq(T(i)->s, T(i)->n, "_") && K(i + 1) == K_COLON) lab = 1;
        else { int j = i; if (K(j) == K_MINUS) j++; if ((K(j) == K_INT || K(j) == K_DBL || K(j) == K_STR) && K(j + 1) == K_COLON) lab = 1; }
        if (lab) return parse_switch();
      }
      if (header_inline_start(after) && !(after == K_LB)) return parse_if_chain();
    }
  }
  return parse_simple();
}
static Node *parse_program(void) {
  P = 0; Node *b = mk(S_BLOCK, 1);
  while (K(0) != K_EOF) {
    if (K(0) == K_NL) { P++; continue; }
    if (K(0) == K_DEDENT) fe_error(LN(), "들여쓰기가 맞지 않아요");
    Node *s = parse_stmt();
    if (!(s->k == S_NOP && s->x == -1)) push_node(b, s);
    while (K(0) == K_SEMI) { P++; if (K(0) == K_NL) break; push_node(b, parse_stmt()); }
    end_stmt();
  }
  return b;
}

/* ------------------------------------------------------------------ */
/* name resolution                                                     */
/* ------------------------------------------------------------------ */
static int find_name(char **arr, int n, const char *s, int sn) { for (int i = 0; i < n; i++) if (streq(s, sn, arr[i])) return i; return -1; }
static int builtin_id(const char *s, int sn) {
  for (int i = 0; i < BI_SORT; i++) if (streq(s, sn, rt_bi_names[i])) return i;
  return -1;
}
static int func_id(const char *s, int sn) { for (int i = 0; i < nfunc; i++) if (!funcs[i]->is_lambda && streq(s, sn, funcs[i]->name)) return i; return -1; }
static int add_global(const char *s, int sn, int line) {
  int i = find_name(gnames, ng, s, sn); if (i >= 0) return i;
  if (builtin_id(s, sn) >= 0) { char m[200] = "내장 함수 이름은 변수로 쓸 수 없어요: "; int k = (int)strlen(m); memcpy(m + k, s, sn); m[k + sn] = 0; fe_error(line, m); }
  if (func_id(s, sn) >= 0) fe_error(line, "함수 이름을 변수로 쓸 수 없어요");
  if (ng == capg) { int nc = capg ? capg * 2 : 32; gnames = rt_grow(gnames, sizeof(char *) * capg, sizeof(char *) * nc); gconst = rt_grow(gconst, sizeof(int) * capg, sizeof(int) * nc); capg = nc; }
  gnames[ng] = sdup(s, sn); return ng++;
}
static void collect_globals(Node *s) {
  if (!s) return;
  switch (s->k) {
    case S_BLOCK: for (int i = 0; i < s->n; i++) collect_globals(s->v[i]); break;
    case S_ASSIGN: for (int i = 0; i < s->a->n; i++) { Node *t = s->a->v[i]; if (t->k == N_VAR) add_global(t->s, t->sn, s->line); } break;
    case S_OPASSIGN: case S_INC: if (s->a->k == N_VAR) add_global(s->a->s, s->a->sn, s->line); break;
    case S_DECL: case S_READ: for (int i = 0; i < s->n; i++) add_global(s->v[i]->a->s, s->v[i]->a->sn, s->line); break;
    case S_CONST: { int g = add_global(s->a->s, s->a->sn, s->line); gconst[g] = 1; break; }
    case S_FOREACH: add_global(s->a->s, s->a->sn, s->line); collect_globals(s->c); break;
    case S_FORR: add_global(s->a->s, s->a->sn, s->line); collect_globals(s->v[0]); break;
    case S_FORC: collect_globals(s->a); collect_globals(s->c); collect_globals(s->d); break;
    case S_IF: collect_globals(s->b); collect_globals(s->c); break;
    case S_WHILE: case S_DO: collect_globals(s->b); break;
    case S_SWITCH: for (int i = 0; i < s->n; i++) collect_globals(s->v[i]->b); break;
  }
}
static Func *cur_fn;
static int add_local(Func *f, const char *s, int sn) {
  int i = find_name(f->loc, f->nloc, s, sn); if (i >= 0) return i;
  if (f->nloc == f->locap) { int nc = f->locap ? f->locap * 2 : 8; f->loc = rt_grow(f->loc, sizeof(char *) * f->locap, sizeof(char *) * nc); f->locap = nc; }
  f->loc[f->nloc] = sdup(s, sn); return f->nloc++;
}
static void collect_locals(Func *f, Node *s) {
  if (!s) return;
#define ADDW(V_) do { Node *v_ = (V_); if (v_->k == N_VAR && find_name(gnames, ng, v_->s, v_->sn) < 0) { \
    if (builtin_id(v_->s, v_->sn) >= 0 || func_id(v_->s, v_->sn) >= 0) fe_error(s->line, "함수 이름에는 값을 넣을 수 없어요"); add_local(f, v_->s, v_->sn); } } while (0)
  switch (s->k) {
    case S_BLOCK: for (int i = 0; i < s->n; i++) collect_locals(f, s->v[i]); break;
    case S_ASSIGN: for (int i = 0; i < s->a->n; i++) ADDW(s->a->v[i]); break;
    case S_OPASSIGN: case S_INC: ADDW(s->a); break;
    case S_DECL: case S_READ: for (int i = 0; i < s->n; i++) ADDW(s->v[i]->a); break;
    case S_CONST: fe_error(s->line, "상수(.이름 =)는 함수 밖에서 정해요");
    case S_FOREACH: ADDW(s->a); collect_locals(f, s->c); break;
    case S_FORR: ADDW(s->a); collect_locals(f, s->v[0]); break;
    case S_FORC: collect_locals(f, s->a); collect_locals(f, s->c); collect_locals(f, s->d); break;
    case S_IF: collect_locals(f, s->b); collect_locals(f, s->c); break;
    case S_WHILE: case S_DO: collect_locals(f, s->b); break;
    case S_SWITCH: for (int i = 0; i < s->n; i++) collect_locals(f, s->v[i]->b); break;
  }
#undef ADDW
}
static void resolve_expr(Node *e);
static void resolve_var(Node *e, int writing) {
  /* scope: 0 global, 1 local, 2 reference param */
  if (cur_fn) {
    int i = find_name(cur_fn->loc, cur_fn->nloc, e->s, e->sn);
    if (i >= 0) { e->x = i; e->y = i < cur_fn->np && cur_fn->isref[i] ? 2 : 1; return; }
  }
  int g = find_name(gnames, ng, e->s, e->sn);
  if (g >= 0) {
    if (writing && gconst[g] && writing != 2) fe_error(e->line, "상수에는 값을 다시 넣을 수 없어요");
    e->x = g; e->y = 0; return;
  }
  int f = func_id(e->s, e->sn);
  if (f >= 0 && !writing) { e->k = N_FNREF; e->x = f; return; }
  int b = builtin_id(e->s, e->sn);
  if (b >= 0 && !writing) { e->k = N_BIREF; e->x = b; return; }
  char m[200]; int k = 0; const char *p = cur_fn && cur_fn->is_lambda ? "람다 안에서는 매개변수와 전역 변수만 쓸 수 있어요: " : "정의되지 않은 이름이에요: ";
  while (*p) m[k++] = *p++; memcpy(m + k, e->s, e->sn); m[k + e->sn] = 0;
  fe_error(e->line, m);
}
static void resolve_lv(Node *e) { if (e->k == N_VAR) resolve_var(e, 1); else { resolve_expr(e->a); resolve_expr(e->b); } }
static void resolve_stmt(Node *s);
static void resolve_func(Func *f);
static void resolve_expr(Node *e) {
  if (!e) return;
  switch (e->k) {
    case N_VAR: resolve_var(e, 0); break;
    case N_BIN: case N_AND: case N_OR: case N_INDEX: resolve_expr(e->a); resolve_expr(e->b); break;
    case N_UN: case N_PREC: resolve_expr(e->a); break;
    case N_TERN: resolve_expr(e->a); resolve_expr(e->b); resolve_expr(e->c); break;
    case N_LIST: case N_BICALL: for (int i = 0; i < e->n; i++) resolve_expr(e->v[i]); break;
    case N_CALLV: resolve_expr(e->a); for (int i = 0; i < e->n; i++) resolve_expr(e->v[i]); break;
    case N_LAMBDA: { Func *save = cur_fn; resolve_func(funcs[e->x]); cur_fn = save; break; }
    case N_CALLN: {
      for (int i = 0; i < e->n; i++) resolve_expr(e->v[i]);
      if (cur_fn && find_name(cur_fn->loc, cur_fn->nloc, e->s, e->sn) >= 0) goto callv;
      if (find_name(gnames, ng, e->s, e->sn) >= 0) goto callv;
      int f = func_id(e->s, e->sn);
      if (f >= 0) {
        Func *fn = funcs[f]; int req = 0; while (req < fn->np && !fn->defs[req]) req++;
        if (e->n < req || e->n > fn->np) fe_error(e->line, "함수에 넘긴 값의 개수가 맞지 않아요");
        for (int i = 0; i < e->n; i++) if (fn->isref[i] && e->v[i]->k != N_VAR) fe_error(e->line, "참조 매개변수(_)에는 변수 이름을 넘겨야 해요");
        e->k = N_CALL; e->x = f; break;
      }
      int b = builtin_id(e->s, e->sn);
      if (b >= 0) { e->k = N_BICALL; e->x = b; break; }
      { char m[200] = "정의되지 않은 함수예요: "; int k = (int)strlen(m); memcpy(m + k, e->s, e->sn); m[k + e->sn] = 0; fe_error(e->line, m); }
    callv: {
        Node *v = mk(N_VAR, e->line); v->s = e->s; v->sn = e->sn; resolve_var(v, 0);
        e->k = N_CALLV; e->a = v; break;
      }
    }
  }
}
static void resolve_target(Node *t) { resolve_lv(t->a); for (int i = 0; i < t->n; i++) resolve_expr(t->v[i]); }
static void resolve_stmt(Node *s) {
  if (!s) return;
  switch (s->k) {
    case S_BLOCK: for (int i = 0; i < s->n; i++) resolve_stmt(s->v[i]); break;
    case S_EXPR: resolve_expr(s->a); break;
    case S_ASSIGN: for (int i = 0; i < s->b->n; i++) resolve_expr(s->b->v[i]); for (int i = 0; i < s->a->n; i++) resolve_lv(s->a->v[i]); break;
    case S_OPASSIGN: resolve_expr(s->b); resolve_lv(s->a); break;
    case S_INC: resolve_lv(s->a); break;
    case S_DECL: case S_READ: for (int i = 0; i < s->n; i++) resolve_target(s->v[i]); break;
    case S_PRINT: for (int i = 0; i < s->n; i++) resolve_expr(s->v[i]); break;
    case S_CONST: resolve_expr(s->b); resolve_var(s->a, 2); break;
    case S_IF: resolve_expr(s->a); resolve_stmt(s->b); resolve_stmt(s->c); break;
    case S_SWITCH: resolve_expr(s->a); for (int i = 0; i < s->n; i++) { resolve_expr(s->v[i]->a); resolve_stmt(s->v[i]->b); } break;
    case S_FORC: resolve_stmt(s->a); resolve_expr(s->b); resolve_stmt(s->c); resolve_stmt(s->d); break;
    case S_FORR: resolve_lv(s->a); resolve_expr(s->b); resolve_expr(s->c); resolve_expr(s->d); resolve_stmt(s->v[0]); break;
    case S_WHILE: case S_DO: resolve_expr(s->a); resolve_stmt(s->b); break;
    case S_FOREACH: resolve_lv(s->a); resolve_expr(s->b); resolve_stmt(s->c); break;
    case S_RET: if (!cur_fn) fe_error(s->line, ".... 반환은 함수 안에서만 써요"); resolve_expr(s->a); break;
  }
}
static void resolve_func(Func *f) {
  Func *save = cur_fn; cur_fn = f;
  for (int i = 0; i < f->np; i++) {
    if (find_name(f->loc, f->nloc, f->pn[i], (int)strlen(f->pn[i])) >= 0) fe_error(f->line, "매개변수 이름이 겹쳐요");
    add_local(f, f->pn[i], (int)strlen(f->pn[i]));
  }
  if (!f->is_lambda) collect_locals(f, f->body);
  for (int i = 0; i < f->np; i++) if (f->defs[i]) { Func *s2 = cur_fn; cur_fn = 0; resolve_expr(f->defs[i]); cur_fn = s2; }
  resolve_stmt(f->body);
  cur_fn = save;
}
static Node *program;
static void compile(const char *src, int len) {
  nfunc = 0; ng = 0; funcs = 0; capfunc = 0; gnames = 0; capg = 0; gconst = 0;
  lex(src, len);
  program = parse_program();
  for (int i = 0; i < nfunc; i++) {
    Func *f = funcs[i]; if (f->is_lambda) continue;
    if (builtin_id(f->name, (int)strlen(f->name)) >= 0) fe_error(f->line, "내장 함수와 같은 이름의 함수는 만들 수 없어요");
    for (int j = 0; j < i; j++) if (!funcs[j]->is_lambda && !strcmp_same(funcs[j]->name, f->name)) fe_error(f->line, "같은 이름의 함수가 두 번 있어요");
  }
  collect_globals(program);
  cur_fn = 0;
  int nf0 = nfunc;
  for (int i = 0; i < nf0; i++) if (!funcs[i]->is_lambda) resolve_func(funcs[i]);
  cur_fn = 0; resolve_stmt(program);
}

#include "back.c"
