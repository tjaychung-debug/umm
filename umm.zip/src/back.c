/* ===================================================================
 * umm back end: tree-walking interpreter and C code generator.
 * Included at the end of dot.c.
 * =================================================================== */

/* ------------------------------------------------------------------ */
/* interpreter                                                         */
/* ------------------------------------------------------------------ */
typedef struct Env { V *v; V **r; } Env;
static V *G;
enum { X_NORM, X_BRK, X_CONT, X_RET };
static V eval(Node *e, Env *E);
static int exec(Node *s, Env *E, V *ret);
static Env genv;

static V *lref(Node *e, Env *E) {
  if (e->k == N_VAR) { if (e->y == 0) return &G[e->x]; if (e->y == 2) return E->r[e->x]; return &E->v[e->x]; }
  V c = eval(e->a, E); V i = eval(e->b, E);
  return rt_ref(c, i);
}
static V run_func(Func *f, V *vals, V **refs) {
  int nl = f->nloc > 0 ? f->nloc : 1;
  V loc[nl]; memset(loc, 0, sizeof(V) * nl);
  for (int i = 0; i < f->np; i++) loc[i] = vals[i];
  Env ne = { loc, refs };
  V ret = vi(0);
  int save = rt_line;
  exec(f->body, &ne, &ret);
  rt_line = save;
  return ret;
}
static V call_user(Func *f, Node *call, Env *E) {
  int np = f->np > 0 ? f->np : 1;
  V vals[np]; V *refs[np];
  for (int i = 0; i < f->np; i++) {
    refs[i] = 0; vals[i] = vi(0);
    if (i < call->n) { if (f->isref[i]) refs[i] = lref(call->v[i], E); else vals[i] = eval(call->v[i], E); }
    else vals[i] = eval(f->defs[i], &genv);
  }
  return run_func(f, vals, refs);
}
static V interp_apply(void *ast, V *args, int n) {
  Func *f = ast;
  if (n != f->np) rt_error("함수에 넘긴 값의 개수가 맞지 않아요");
  for (int i = 0; i < f->np; i++) if (f->isref[i]) rt_error("참조 매개변수(_)가 있는 함수는 값으로 넘길 수 없어요");
  return run_func(f, args, 0);
}
static V fnval(Func *f) {
  for (int i = 0; i < f->np; i++) if (f->isref[i]) rt_error("참조 매개변수(_)가 있는 함수는 값으로 넘길 수 없어요");
  return rt_mkfn_ast(f, f->np);
}
static V eval_bin(int op, V a, V b) {
  switch (op) {
    case K_PLUS: return rt_add(a, b); case K_MINUS: return rt_sub(a, b);
    case K_STAR: return rt_mul(a, b); case K_SLASH: return rt_div(a, b); case K_PCT: return rt_mod(a, b);
    case K_EQ: return rt_eq(a, b); case K_NE: return rt_ne(a, b);
    case K_LT: return rt_lt(a, b); case K_GT: return rt_gt(a, b); case K_LE: return rt_le(a, b); case K_GE: return rt_ge(a, b);
    case K_BAND: return rt_band(a, b); case K_BOR: return rt_bor(a, b); case K_BXOR: return rt_bxor(a, b);
    case K_SHL: return rt_shl(a, b); case K_SHR: return rt_shr(a, b);
  }
  rt_error("알 수 없는 연산자예요");
}
static V eval(Node *e, Env *E) {
  switch (e->k) {
    case N_INT: return vi(e->i);
    case N_DBL: return vd(e->dv);
    case N_STR: return vstr(e->s, e->sn);
    case N_NIL: return vnil();
    case N_VAR: return *lref(e, E);
    case N_BIN: { V a = eval(e->a, E); V b = eval(e->b, E); return eval_bin(e->x, a, b); }
    case N_UN: { V a = eval(e->a, E); return e->x == K_MINUS ? rt_neg(a) : e->x == K_NOT ? rt_not(a) : rt_bnot(a); }
    case N_AND: return vi(rt_truthy(eval(e->a, E)) && rt_truthy(eval(e->b, E)));
    case N_OR: return vi(rt_truthy(eval(e->a, E)) || rt_truthy(eval(e->b, E)));
    case N_TERN: return rt_truthy(eval(e->a, E)) ? eval(e->b, E) : eval(e->c, E);
    case N_INDEX: { V c = eval(e->a, E); V i = eval(e->b, E); return rt_index(c, i); }
    case N_CALL: return call_user(funcs[e->x], e, E);
    case N_BICALL: { int n = e->n; V a[n > 0 ? n : 1]; for (int i = 0; i < n; i++) a[i] = eval(e->v[i], E); return rt_bi(e->x, a, n); }
    case N_CALLV: { V f = eval(e->a, E); int n = e->n; V a[n > 0 ? n : 1]; for (int i = 0; i < n; i++) a[i] = eval(e->v[i], E); return rt_apply(f, a, n); }
    case N_FNREF: return fnval(funcs[e->x]);
    case N_LAMBDA: return fnval(funcs[e->x]);
    case N_BIREF: return rt_mkfn_bi(e->x);
    case N_LIST: { int n = e->n; V a[n > 0 ? n : 1]; for (int i = 0; i < n; i++) a[i] = eval(e->v[i], E); return rt_listlit(a, n); }
    case N_PREC: return rt_fmtp(eval(e->a, E), e->x);
  }
  rt_error("알 수 없는 식이에요");
}
static i64 dims_of(Node *t, Env *E, i64 *d) { for (int i = 0; i < t->n; i++) d[i] = toint(eval(t->v[i], E), "크기는 정수여야 해요"); return t->n; }
static int exec(Node *s, Env *E, V *ret) {
  rt_line = s->line;
  switch (s->k) {
    case S_BLOCK:
      for (int i = 0; i < s->n; i++) { int r = exec(s->v[i], E, ret); if (r != X_NORM) return r; }
      return X_NORM;
    case S_NOP: return X_NORM;
    case S_EXPR: eval(s->a, E); return X_NORM;
    case S_ASSIGN: {
      int n = s->a->n; V t[n];
      for (int i = 0; i < n; i++) t[i] = eval(s->b->v[i], E);
      for (int i = 0; i < n; i++) *lref(s->a->v[i], E) = t[i];
      return X_NORM;
    }
    case S_CONST: { V v = eval(s->b, E); *lref(s->a, E) = v; return X_NORM; }
    case S_OPASSIGN: {
      V r = eval(s->b, E); V *p = lref(s->a, E);
      switch (s->x) {
        case K_ADDEQ: rt_addto(p, r); break;
        case K_SUBEQ: rt_subfrom(p, r); break;
        case K_MULEQ: *p = rt_mul(*p, r); break;
        case K_DIVEQ: *p = rt_div(*p, r); break;
        case K_MODEQ: *p = rt_mod(*p, r); break;
      }
      return X_NORM;
    }
    case S_INC: { V *p = lref(s->a, E); *p = rt_add(*p, vi(s->x)); return X_NORM; }
    case S_DECL: case S_READ:
      for (int i = 0; i < s->n; i++) {
        Node *t = s->v[i]; i64 d[8]; int nd = (int)dims_of(t, E, d);
        V v = nd == 0 ? (s->k == S_DECL ? vi(0) : rt_read()) : (s->k == S_DECL ? rt_zeros(d, nd) : rt_readdims(d, nd));
        *lref(t->a, E) = v;
      }
      return X_NORM;
    case S_PRINT:
      for (int i = 0; i < s->n; i++) { if (i) rt_putc(' '); rt_print(eval(s->v[i], E)); }
      rt_putc('\n');
      return X_NORM;
    case S_IF:
      if (rt_truthy(eval(s->a, E))) return exec(s->b, E, ret);
      return s->c ? exec(s->c, E, ret) : X_NORM;
    case S_SWITCH: {
      V v = eval(s->a, E); Node *def = 0;
      for (int i = 0; i < s->n; i++) {
        Node *c = s->v[i];
        if (!c->a) { def = c; continue; }
        if (!rt_cmp(v, eval(c->a, E))) return exec(c->b, E, ret);
      }
      return def ? exec(def->b, E, ret) : X_NORM;
    }
    case S_FORC: {
      exec(s->a, E, ret);
      for (;;) {
        if (s->b && !rt_truthy(eval(s->b, E))) break;
        int r = exec(s->d, E, ret);
        if (r == X_BRK) break;
        if (r == X_RET) return r;
        exec(s->c, E, ret);
      }
      return X_NORM;
    }
    case S_FORR: {
      i64 a = toint(eval(s->b, E), "반복 범위는 정수여야 해요"), b = toint(eval(s->c, E), "반복 범위는 정수여야 해요");
      i64 st = s->d ? toint(eval(s->d, E), "간격은 정수여야 해요") : 1;
      if (!st) rt_error("반복 간격이 0이에요");
      for (i64 i = a; st > 0 ? i < b : i > b; i += st) {
        *lref(s->a, E) = vi(i);
        int r = exec(s->v[0], E, ret);
        if (r == X_BRK) break;
        if (r == X_RET) return r;
      }
      return X_NORM;
    }
    case S_WHILE:
      while (rt_truthy(eval(s->a, E))) { int r = exec(s->b, E, ret); if (r == X_BRK) break; if (r == X_RET) return r; }
      return X_NORM;
    case S_DO:
      do { int r = exec(s->b, E, ret); if (r == X_BRK) break; if (r == X_RET) return r; } while (rt_truthy(eval(s->a, E)));
      return X_NORM;
    case S_FOREACH: {
      V l = rt_iterlist(eval(s->b, E));
      for (int i = 0; i < LST(l)->n; i++) {
        *lref(s->a, E) = LST(l)->a[i];
        int r = exec(s->c, E, ret);
        if (r == X_BRK) break;
        if (r == X_RET) return r;
      }
      return X_NORM;
    }
    case S_BREAK: return X_BRK;
    case S_CONT: return X_CONT;
    case S_RET: *ret = s->a ? eval(s->a, E) : vi(0); return X_RET;
  }
  rt_error("알 수 없는 문장이에요");
}
static void interpret(void) {
  G = rt_alloc(sizeof(V) * (ng > 0 ? ng : 1));
  rt_hook_apply = interp_apply;
  genv.v = 0; genv.r = 0;
  V ret = vi(0);
  int r = exec(program, &genv, &ret);
  (void)r;
  rt_line = 0;
}

/* ------------------------------------------------------------------ */
/* C code generator                                                    */
/* ------------------------------------------------------------------ */
static Buf *CB;
static int lbl;
static int loopk[256], loopl[256], nloop;   /* kind 1 = C-style for (needs goto for continue) */
static Node **strs; static int nstr, capstr;
static Func *gen_fn;

static void cs(const char *s) { bs(CB, s); }
static void ci(i64 x) { bi(CB, x); }
static void cname(const char *pre, const char *s) { cs(pre); cs(s); }
static void cind(int d) { for (int i = 0; i < d; i++) cs("  "); }

static int str_index(Node *e) {
  if (nstr == capstr) { int nc = capstr ? capstr * 2 : 16; strs = rt_grow(strs, sizeof(Node *) * capstr, sizeof(Node *) * nc); capstr = nc; }
  strs[nstr] = e; return nstr++;
}
static void cstrlit(const char *s, int n) {
  cs("\"");
  for (int i = 0; i < n; i++) {
    unsigned char c = (unsigned char)s[i];
    if (c == '"' || c == '\\') { char t[3] = { '\\', (char)c, 0 }; cs(t); }
    else if (c >= 32 && c < 127 && c != '?') { char t[2] = { (char)c, 0 }; cs(t); }
    else { char t[5] = { '\\', (char)('0' + (c >> 6)), (char)('0' + ((c >> 3) & 7)), (char)('0' + (c & 7)), 0 }; cs(t); }
  }
  cs("\"");
}
static void ce(Node *e);
static void cvar(Node *e) {
  if (e->y == 0) cname("g_", gnames[e->x]);
  else if (e->y == 2) { cs("(*"); cname("l_", gen_fn->loc[e->x]); cs(")"); }
  else cname("l_", gen_fn->loc[e->x]);
}
static void clv(Node *e) {
  if (e->k == N_VAR) {
    if (e->y == 2) cname("l_", gen_fn->loc[e->x]);
    else { cs("&"); cvar(e); }
    return;
  }
  cs("rt_ref("); ce(e->a); cs(", "); ce(e->b); cs(")");
}
static void cargs(Node *e) {
  if (!e->n) { cs("0, 0"); return; }
  cs("(V[]){ ");
  for (int i = 0; i < e->n; i++) { if (i) cs(", "); ce(e->v[i]); }
  cs(" }, "); ci(e->n);
}
static const char *binfn(int op) {
  switch (op) {
    case K_PLUS: return "rt_add"; case K_MINUS: return "rt_sub"; case K_STAR: return "rt_mul"; case K_SLASH: return "rt_div"; case K_PCT: return "rt_mod";
    case K_EQ: return "rt_eq"; case K_NE: return "rt_ne"; case K_LT: return "rt_lt"; case K_GT: return "rt_gt"; case K_LE: return "rt_le"; case K_GE: return "rt_ge";
    case K_BAND: return "rt_band"; case K_BOR: return "rt_bor"; case K_BXOR: return "rt_bxor"; case K_SHL: return "rt_shl"; case K_SHR: return "rt_shr";
  }
  return "?";
}
static void cfnname(Func *f) { if (f->is_lambda) { cs("lam_"); ci(f->id); } else cname("fn_", f->name); }
static void cfnval(Func *f) {
  for (int i = 0; i < f->np; i++) if (f->isref[i]) fe_error(f->line, "참조 매개변수(_)가 있는 함수는 값으로 넘길 수 없어요");
  cs("rt_mkfn((void *)"); cfnname(f); cs(", "); ci(f->np); cs(")");
}
static void ce(Node *e) {
  switch (e->k) {
    case N_INT:
      if (e->i == (-9223372036854775807LL - 1)) cs("vi(-9223372036854775807LL - 1)");
      else { cs("vi("); ci(e->i); cs("LL)"); }
      return;
    case N_DBL: {
      int hasdot = 0; for (int i = 0; i < e->sn; i++) if (e->s[i] == '.' || e->s[i] == 'e' || e->s[i] == 'E') hasdot = 1;
      cs("vd("); bput(CB, e->s, e->sn); if (!hasdot) cs(".0"); cs(")"); return;
    }
    case N_STR: { int k = str_index(e); cs("S_["); ci(k); cs("]"); return; }
    case N_NIL: cs("vnil()"); return;
    case N_VAR: cvar(e); return;
    case N_BIN: cs(binfn(e->x)); cs("("); ce(e->a); cs(", "); ce(e->b); cs(")"); return;
    case N_UN: cs(e->x == K_MINUS ? "rt_neg(" : e->x == K_NOT ? "rt_not(" : "rt_bnot("); ce(e->a); cs(")"); return;
    case N_AND: cs("vi(rt_truthy("); ce(e->a); cs(") && rt_truthy("); ce(e->b); cs("))"); return;
    case N_OR: cs("vi(rt_truthy("); ce(e->a); cs(") || rt_truthy("); ce(e->b); cs("))"); return;
    case N_TERN: cs("(rt_truthy("); ce(e->a); cs(") ? "); ce(e->b); cs(" : "); ce(e->c); cs(")"); return;
    case N_INDEX: cs("rt_index("); ce(e->a); cs(", "); ce(e->b); cs(")"); return;
    case N_CALL: {
      Func *f = funcs[e->x]; cfnname(f); cs("(");
      for (int i = 0; i < f->np; i++) {
        if (i) cs(", ");
        if (i < e->n) { if (f->isref[i]) clv(e->v[i]); else ce(e->v[i]); }
        else { Func *s = gen_fn; gen_fn = 0; ce(f->defs[i]); gen_fn = s; }
      }
      cs(")"); return;
    }
    case N_BICALL: cs("rt_bi("); ci(e->x); cs(" /* "); cs(rt_bi_names[e->x]); cs(" */, "); cargs(e); cs(")"); return;
    case N_CALLV: cs("rt_apply("); ce(e->a); cs(", "); cargs(e); cs(")"); return;
    case N_FNREF: case N_LAMBDA: cfnval(funcs[e->x]); return;
    case N_BIREF: cs("rt_mkfn_bi("); ci(e->x); cs(")"); return;
    case N_LIST: if (!e->n) { cs("vlist(4)"); return; } cs("rt_listlit("); cargs(e); cs(")"); return;
    case N_PREC: cs("rt_fmtp("); ce(e->a); cs(", "); ci(e->x); cs(")"); return;
  }
}
static void cstmt(Node *s, int d);
static void cblock(Node *b, int d) { for (int i = 0; i < b->n; i++) cstmt(b->v[i], d); }
static void cdims(Node *t) {
  cs("(i64[]){ ");
  for (int i = 0; i < t->n; i++) { if (i) cs(", "); cs("toint("); ce(t->v[i]); cs(", \"크기는 정수여야 해요\")"); }
  cs(" }, "); ci(t->n);
}
static void cstmt(Node *s, int d) {
  if (s->k == S_BLOCK) { cblock(s, d); return; }
  if (s->k == S_NOP) return;
  cind(d); cs("rt_line = "); ci(s->line); cs(";\n");
  switch (s->k) {
    case S_EXPR: cind(d); cs("(void)"); ce(s->a); cs(";\n"); break;
    case S_ASSIGN:
      if (s->a->n == 1) { cind(d); cs("{ V t_ = "); ce(s->b->v[0]); cs("; *"); clv(s->a->v[0]); cs(" = t_; }\n"); break; }
      cind(d); cs("{\n");
      for (int i = 0; i < s->a->n; i++) { cind(d + 1); cs("V t"); ci(i); cs("_ = "); ce(s->b->v[i]); cs(";\n"); }
      for (int i = 0; i < s->a->n; i++) { cind(d + 1); cs("*"); clv(s->a->v[i]); cs(" = t"); ci(i); cs("_;\n"); }
      cind(d); cs("}\n"); break;
    case S_CONST: cind(d); cs("{ V t_ = "); ce(s->b); cs("; *"); clv(s->a); cs(" = t_; }\n"); break;
    case S_OPASSIGN:
      cind(d); cs("{ V r_ = "); ce(s->b); cs("; V *p_ = "); clv(s->a); cs("; ");
      switch (s->x) {
        case K_ADDEQ: cs("rt_addto(p_, r_);"); break;
        case K_SUBEQ: cs("rt_subfrom(p_, r_);"); break;
        case K_MULEQ: cs("*p_ = rt_mul(*p_, r_);"); break;
        case K_DIVEQ: cs("*p_ = rt_div(*p_, r_);"); break;
        case K_MODEQ: cs("*p_ = rt_mod(*p_, r_);"); break;
      }
      cs(" }\n"); break;
    case S_INC: cind(d); cs("{ V *p_ = "); clv(s->a); cs("; *p_ = rt_add(*p_, vi("); ci(s->x); cs(")); }\n"); break;
    case S_DECL: case S_READ:
      for (int i = 0; i < s->n; i++) {
        Node *t = s->v[i]; cind(d); cs("{ V t_ = ");
        if (!t->n) cs(s->k == S_DECL ? "vi(0)" : "rt_read()");
        else { cs(s->k == S_DECL ? "rt_zeros(" : "rt_readdims("); cdims(t); cs(")"); }
        cs("; *"); clv(t->a); cs(" = t_; }\n");
      }
      break;
    case S_PRINT:
      for (int i = 0; i < s->n; i++) { cind(d); if (i) cs("rt_putc(' '); "); cs("rt_print("); ce(s->v[i]); cs(");\n"); }
      cind(d); cs("rt_putc('\\n');\n"); break;
    case S_IF: {
      Node *x = s; cind(d);
      for (;;) {
        cs("if (rt_truthy("); ce(x->a); cs(")) {\n"); cstmt(x->b, d + 1); cind(d); cs("}");
        if (!x->c) { cs("\n"); break; }
        if (x->c->k == S_IF) { cs(" else "); x = x->c; continue; }
        cs(" else {\n"); cstmt(x->c, d + 1); cind(d); cs("}\n"); break;
      }
      break;
    }
    case S_SWITCH: {
      int k = lbl++; Node *def = 0; int first = 1;
      cind(d); cs("{ V sw"); ci(k); cs("_ = "); ce(s->a); cs(";\n");
      for (int i = 0; i < s->n; i++) {
        Node *c = s->v[i]; if (!c->a) { def = c; continue; }
        cind(d + 1); if (!first) cs("else "); first = 0;
        cs("if (!rt_cmp(sw"); ci(k); cs("_, "); ce(c->a); cs(")) {\n"); cstmt(c->b, d + 2); cind(d + 1); cs("}\n");
      }
      if (def) { cind(d + 1); if (!first) cs("else "); cs("{\n"); cstmt(def->b, d + 2); cind(d + 1); cs("}\n"); }
      cind(d); cs("}\n"); break;
    }
    case S_FORC: {
      int k = lbl++;
      cind(d); cs("{\n"); cstmt(s->a, d + 1);
      cind(d + 1); cs("for (;;) {\n");
      if (s->b) { cind(d + 2); cs("if (!rt_truthy("); ce(s->b); cs(")) break;\n"); }
      loopk[nloop] = 1; loopl[nloop] = k; nloop++;
      cstmt(s->d, d + 2);
      nloop--;
      cind(d + 2); cs("cont"); ci(k); cs("_:;\n");
      cstmt(s->c, d + 2);
      cind(d + 1); cs("}\n"); cind(d); cs("}\n"); break;
    }
    case S_FORR: {
      int k = lbl++;
      cind(d); cs("{ i64 a"); ci(k); cs("_ = toint("); ce(s->b); cs(", \"반복 범위는 정수여야 해요\"), b"); ci(k); cs("_ = toint("); ce(s->c); cs(", \"반복 범위는 정수여야 해요\"), s"); ci(k); cs("_ = ");
      if (s->d) { cs("toint("); ce(s->d); cs(", \"간격은 정수여야 해요\")"); } else cs("1");
      cs(";\n");
      cind(d + 1); cs("if (!s"); ci(k); cs("_) rt_error(\"반복 간격이 0이에요\");\n");
      cind(d + 1); cs("for (i64 i"); ci(k); cs("_ = a"); ci(k); cs("_; s"); ci(k); cs("_ > 0 ? i"); ci(k); cs("_ < b"); ci(k); cs("_ : i"); ci(k); cs("_ > b"); ci(k); cs("_; i"); ci(k); cs("_ += s"); ci(k); cs("_) {\n");
      cind(d + 2); cs("*"); clv(s->a); cs(" = vi(i"); ci(k); cs("_);\n");
      loopk[nloop] = 0; nloop++; cstmt(s->v[0], d + 2); nloop--;
      cind(d + 1); cs("}\n"); cind(d); cs("}\n"); break;
    }
    case S_WHILE:
      cind(d); cs("while (rt_truthy("); ce(s->a); cs(")) {\n");
      loopk[nloop] = 0; nloop++; cstmt(s->b, d + 1); nloop--;
      cind(d); cs("}\n"); break;
    case S_DO:
      cind(d); cs("do {\n");
      loopk[nloop] = 0; nloop++; cstmt(s->b, d + 1); nloop--;
      cind(d); cs("} while (rt_truthy("); ce(s->a); cs("));\n"); break;
    case S_FOREACH: {
      int k = lbl++;
      cind(d); cs("{ V it"); ci(k); cs("_ = rt_iterlist("); ce(s->b); cs(");\n");
      cind(d + 1); cs("for (int k"); ci(k); cs("_ = 0; k"); ci(k); cs("_ < LST(it"); ci(k); cs("_)->n; k"); ci(k); cs("_++) {\n");
      cind(d + 2); cs("*"); clv(s->a); cs(" = LST(it"); ci(k); cs("_)->a[k"); ci(k); cs("_];\n");
      loopk[nloop] = 0; nloop++; cstmt(s->c, d + 2); nloop--;
      cind(d + 1); cs("}\n"); cind(d); cs("}\n"); break;
    }
    case S_BREAK: if (!nloop) fe_error(s->line, "-- (멈춤)은 반복문 안에서만 써요"); cind(d); cs("break;\n"); break;
    case S_CONT:
      if (!nloop) fe_error(s->line, "- (건너뛰기)는 반복문 안에서만 써요");
      cind(d);
      if (loopk[nloop - 1] == 1) { cs("goto cont"); ci(loopl[nloop - 1]); cs("_;\n"); } else cs("continue;\n");
      break;
    case S_RET: cind(d); cs("return "); if (s->a) ce(s->a); else cs("vi(0)"); cs(";\n"); break;
  }
}
static void cproto(Func *f) {
  cs("static V "); cfnname(f); cs("(");
  if (!f->np) cs("void");
  for (int i = 0; i < f->np; i++) { if (i) cs(", "); cs(f->isref[i] ? "V *" : "V "); cname("l_", f->loc[i]); }
  cs(")");
}
static void codegen(Buf *out) {
  Buf body = { 0 };
  CB = &body; lbl = 0; nloop = 0; nstr = 0; strs = 0; capstr = 0;
  /* functions */
  for (int i = 0; i < nfunc; i++) {
    Func *f = funcs[i]; gen_fn = f;
    cproto(f); cs(" {\n");
    for (int j = f->np; j < f->nloc; j++) { cs("  V "); cname("l_", f->loc[j]); cs(" = vi(0);\n"); }
    cstmt(f->body, 1);
    cs("  return vi(0);\n}\n\n");
  }
  /* main */
  gen_fn = 0;
  cs("int main(void) {\n  rt_init();\n");
  int strmark = body.n;
  cstmt(program, 1);
  cs("  rt_flush();\n  return 0;\n}\n");
  /* string table initialisation is inserted at the top of main */
  Buf init = { 0 }; CB = &init;
  for (int i = 0; i < nstr; i++) { cs("  S_["); ci(i); cs("] = vstr("); cstrlit(strs[i]->s, strs[i]->sn); cs(", "); ci(strs[i]->sn); cs(");\n"); }

  CB = out;
  cs("/* ==================================================================\n");
  cs(" * Generated by umm -> C. Paste this whole file into the judge (C, gcc).\n");
  cs(" * The runtime below is the same one the umm IDE uses to run your code.\n");
  cs(" * ================================================================== */\n");
  cs("#define RT_NATIVE 1\n#pragma GCC diagnostic ignored \"-Wunused-function\"\n");
  bs(out, RT_SRC);
  cs("\n/* ======================= your program ======================= */\n");
  for (int i = 0; i < ng; i++) { cs("static V "); cname("g_", gnames[i]); cs(";\n"); }
  if (nstr) { cs("static V S_["); ci(nstr); cs("];\n"); }
  for (int i = 0; i < nfunc; i++) { cproto(funcs[i]); cs(";\n"); }
  cs("\n");
  bput(out, body.s, strmark);
  if (init.n) bput(out, init.s, init.n);
  bput(out, body.s + strmark, body.n - strmark);
}

/* ------------------------------------------------------------------ */
/* entry points                                                        */
/* ------------------------------------------------------------------ */
#ifdef DOT_CLI
static char *read_file(const char *path, int *len) {
  FILE *f = fopen(path, "rb"); if (!f) { fprintf(stderr, "파일을 열 수 없어요: %s\n", path); exit(2); }
  fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
  char *b = malloc(n + 1); if (fread(b, 1, n, f) != (size_t)n) { exit(2); } b[n] = 0; fclose(f); *len = (int)n; return b;
}
int main(int argc, char **argv) {
  if (argc < 3) { fprintf(stderr, "사용법: dot run 파일.dt  |  dot c 파일.dt\n"); return 2; }
  int len; char *src = read_file(argv[2], &len);
  compile(src, len);
  if (!strcmp(argv[1], "c")) { Buf b = { 0 }; codegen(&b); fwrite(b.s, 1, b.n, stdout); return 0; }
  rt_init(); interpret(); rt_flush(); return 0;
}
#else
__attribute__((export_name("dot_alloc"))) void *dot_alloc(int n) { return rt_alloc((size_t)n); }
__attribute__((export_name("dot_out_ptr"))) char *dot_out_ptr(void) { return out_buf; }
__attribute__((export_name("dot_out_len"))) int dot_out_len(void) { return (int)out_len; }
__attribute__((export_name("dot_run"))) int dot_run(const char *src, int sl, const char *in, int il) {
  in_buf = in; in_len = (size_t)il; in_pos = 0; out_len = 0;
  compile(src, sl); interpret(); return 0;
}
__attribute__((export_name("dot_tocc"))) int dot_tocc(const char *src, int sl) {
  out_len = 0; compile(src, sl);
  Buf b = { 0 }; codegen(&b); rt_write(b.s, (size_t)b.n); return 0;
}
__attribute__((export_name("dot_check"))) int dot_check(const char *src, int sl) { out_len = 0; compile(src, sl); return 0; }
#endif
