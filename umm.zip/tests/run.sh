#!/usr/bin/env bash
# Cross-check: interpreter output must equal output of the generated C program.
cd "$(dirname "$0")"; pass=0; fail=0
for f in t*.um; do t=${f%.um}; in=$t.in; [ -f $in ] || in=/dev/null
  ../bin/dot run $f < $in > /tmp/$t.i 2>/tmp/$t.ie; e1=$?
  ../bin/dot c $f > /tmp/$t.c && gcc -std=gnu11 -O2 -w -o /tmp/$t.bin /tmp/$t.c -lm 2>/tmp/$t.ce && /tmp/$t.bin < $in > /tmp/$t.g 2>/tmp/$t.ge; e2=$?
  if [ -f $t.expect ]; then exp=$t.expect; else exp=/tmp/$t.i; fi
  if [ $e1 -eq 0 ] && [ $e2 -eq 0 ] && cmp -s /tmp/$t.i /tmp/$t.g && cmp -s /tmp/$t.i $exp; then pass=$((pass+1)); echo "PASS $t"
  else fail=$((fail+1)); echo "FAIL $t (interp=$e1 c=$e2)"; head -3 /tmp/$t.ie /tmp/$t.ce /tmp/$t.ge 2>/dev/null; fi
done; echo "$pass passed, $fail failed"; [ $fail -eq 0 ]
